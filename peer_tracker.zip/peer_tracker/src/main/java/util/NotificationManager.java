package util;

import controller.NotificationController;
import model.Notification;

import java.util.Timer;
import java.util.TimerTask;
import javax.swing.JOptionPane;
import java.util.List;

public class NotificationManager {
    private NotificationController notificationController;
    private Timer timer;
    
    public NotificationManager(NotificationController notificationController) {
        this.notificationController = notificationController;
        this.timer = new Timer(true); // Daemon thread
    }
    
    public void startForUser(int userId) {
        timer.scheduleAtFixedRate(new NotificationCheckTask(userId), 0, 300000); // Check every 5 minutes
    }
    
    public void stop() {
        timer.cancel();
    }
    
    private class NotificationCheckTask extends TimerTask {
        private int userId;
        
        public NotificationCheckTask(int userId) {
            this.userId = userId;
        }
        
        @Override
        public void run() {
            List<Notification> unread = notificationController.getUnreadNotifications(userId);
            if (!unread.isEmpty()) {
                // Could trigger a system tray notification or update UI
                System.out.println("User " + userId + " has " + unread.size() + " unread notifications");
            }
        }
    }
}