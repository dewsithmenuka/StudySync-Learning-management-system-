package util;

import model.Quiz;
import model.User;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;

import java.io.IOException;
import java.time.format.DateTimeFormatter;

public class ReportGenerator {
    public void generateQuizReport(Quiz quiz, User user, int score, String filePath) throws IOException {
        try (PDDocument document = new PDDocument()) {
            PDPage page = new PDPage();
            document.addPage(page);
            
            try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
                // Set up fonts
                contentStream.setFont(PDType1Font.HELVETICA_BOLD, 16);
                
                // Add title
                contentStream.beginText();
                contentStream.newLineAtOffset(50, 700);
                contentStream.showText("Quiz Results Report");
                contentStream.endText();
                
                // Add quiz info
                contentStream.setFont(PDType1Font.HELVETICA, 12);
                contentStream.beginText();
                contentStream.newLineAtOffset(50, 650);
                contentStream.showText("Quiz: " + quiz.getTitle());
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Student: " + user.getName());
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText("Date: " + java.time.LocalDateTime.now()
                    .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
                contentStream.newLineAtOffset(0, -20);
                contentStream.showText(String.format("Score: %d/%d (%.2f%%)", 
                    score, quiz.getTotalPoints(), 
                    ((double) score / quiz.getTotalPoints()) * 100));
                contentStream.endText();
            }
            
            document.save(filePath);
        }
    }
}