// MultipleFiles/ParentChildController.java
package controller;

import dao.CourseDAO; // Added for ContactTeacherListener
import dao.EnrollmentDAO; // Added for ContactTeacherListener
import dao.UserDAO;
import model.Enrollment; // Added for ContactTeacherListener
import model.User;
import model.StudentProgress; // Added for progress tracking
import view.ParentDashboardView;
import view.StudentDetailsDialog; // New dialog for student details
import model.Course; // Import Course model

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.util.ArrayList; // Added
import java.util.List;
import java.util.stream.Collectors; // Added

public class ParentChildController {
    private UserDAO userDAO;
    private EnrollmentDAO enrollmentDAO; // Added
    private CourseDAO courseDAO; // Added
    private ParentDashboardView parentDashboardView;
    private int currentParentId; // To store the logged-in parent's ID

    public ParentChildController(UserDAO userDAO, ParentDashboardView parentDashboardView, int currentParentId) {
        this.userDAO = userDAO;
        this.enrollmentDAO = new EnrollmentDAO(); // Initialize
        this.courseDAO = new CourseDAO(); // Initialize
        this.parentDashboardView = parentDashboardView;
        this.currentParentId = currentParentId; // Set the parent ID

        // Load initially linked children
        loadLinkedChildren(currentParentId);

        // Add action listeners
        parentDashboardView.addLinkChildListener(new LinkChildListener());
        parentDashboardView.addSearchStudentListener(new SearchStudentListener());
        parentDashboardView.addViewStudentDetailsListener(new ViewStudentDetailsListener()); // New listener
        parentDashboardView.addRefreshProgressListener(new RefreshProgressListener()); // New listener
    }

    class LinkChildListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedStudentId = parentDashboardView.getSelectedStudentIdFromSearchResults();
            if (selectedStudentId != -1) {
                // Confirm with the parent
                int confirm = JOptionPane.showConfirmDialog(parentDashboardView,
                    "Are you sure you want to link this student as your child?", "Confirm Link", JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    User child = userDAO.getUserById(selectedStudentId);
                    if (child != null && child.getRole().equals("Student")) {
                        child.setParentId(currentParentId); // Set the parent_id
                        boolean success = userDAO.updateUser(child);
                        if (success) {
                            JOptionPane.showMessageDialog(parentDashboardView,
                                "Child linked successfully",
                                "Success",
                                JOptionPane.INFORMATION_MESSAGE);
                            loadLinkedChildren(currentParentId); // Refresh linked children list
                        } else {
                            JOptionPane.showMessageDialog(parentDashboardView,
                                "Failed to link child. Please try again.",
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                        }
                    } else {
                        JOptionPane.showMessageDialog(parentDashboardView,
                            "Selected user is not a student or does not exist.",
                            "Invalid Selection",
                            JOptionPane.WARNING_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(parentDashboardView,
                    "Please select a student from the search results first",
                    "No Student Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    class SearchStudentListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String searchTerm = parentDashboardView.getSearchTerm();
            if (!searchTerm.isEmpty()) {
                List<User> students = userDAO.searchUsers(searchTerm);
                // Filter to only show students
                students.removeIf(user -> !user.getRole().equals("Student"));
                parentDashboardView.displaySearchResults(students);
            } else {
                JOptionPane.showMessageDialog(parentDashboardView,
                    "Please enter a search term.",
                    "Empty Search",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    class ViewStudentDetailsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedStudentId = parentDashboardView.getSelectedStudentIdFromSearchResults();
            if (selectedStudentId != -1) {
                User student = userDAO.getUserById(selectedStudentId);
                if (student != null) {
                    // Fetch student's courses and assignments for the dialog
                    List<Enrollment> enrollments = enrollmentDAO.getEnrollmentsByStudent(student.getUserId());
                    List<Course> studentCourses = new ArrayList<>();
                    for (Enrollment enrollment : enrollments) {
                        Course course = courseDAO.getCourseById(enrollment.getCourseId());
                        if (course != null) {
                            studentCourses.add(course);
                        }
                    }
                    // You might also want to fetch assignments for these courses
                    // For simplicity, we'll just pass the student and their courses for now
                    new StudentDetailsDialog(parentDashboardView, student, studentCourses).setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(parentDashboardView,
                        "Student details not found.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(parentDashboardView,
                    "Please select a student from the search results first",
                    "No Student Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    class RefreshProgressListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String filter = parentDashboardView.getSelectedChildFilter();
            int childIdFilter = -1; // Default to no filter

            if (!"All Children".equals(filter)) {
                // Find the child ID based on the selected name in the filter
                List<User> linkedChildren = userDAO.getChildrenByParent(currentParentId);
                for (User child : linkedChildren) {
                    if (child.getName().equals(filter)) {
                        childIdFilter = child.getUserId();
                        break;
                    }
                }
            }
            loadChildProgress(currentParentId, childIdFilter);
        }
    }

    // Load children linked to parent
    public void loadLinkedChildren(int parentId) {
        List<User> children = userDAO.getChildrenByParent(parentId);
        parentDashboardView.displayChildren(children);
        // Also load progress for all children initially
        loadChildProgress(parentId, -1); // -1 means no specific child filter
    }

    public void loadChildProgress(int parentId, int childIdFilter) {
        List<StudentProgress> allProgress = new ArrayList<>();
        List<User> children = userDAO.getChildrenByParent(parentId);

        for (User child : children) {
            if (childIdFilter == -1 || child.getUserId() == childIdFilter) {
                // Assuming getStudentProgressByTeacher can be adapted or a new method is added
                // to EnrollmentDAO to get progress for a specific student across their courses.
                // For now, we'll use getStudentProgressByTeacher and assume the teacherId is the child's ID
                // which is not ideal. A better approach would be a dedicated DAO method.
                // Let's simulate by getting all enrollments for the student and then their progress.
                List<Enrollment> enrollments = enrollmentDAO.getEnrollmentsByStudent(child.getUserId());
                for (Enrollment enrollment : enrollments) {
                    // This is a simplified way. Ideally, you'd have a method in EnrollmentDAO
                    // that returns StudentProgress for a given student and course.
                    // For demonstration, we'll create a dummy StudentProgress.
                    Course course = courseDAO.getCourseById(enrollment.getCourseId());
                    if (course != null) {
                        // This part needs actual data from submissions/assignments
                        // For now, dummy values
                        allProgress.add(new StudentProgress(
                            child.getUserId(),
                            child.getName(),
                            course.getCourseId(),
                            course.getTitle(),
                            0, // completedAssignments
                            0, // totalAssignments
                            0.0, // averageScore
                            "N/A", // lastActiveDate
                            enrollment.getProgress() // Use enrollment progress
                        ));
                    }
                }
            }
        }
        parentDashboardView.displayChildProgress(allProgress);
    }
}
