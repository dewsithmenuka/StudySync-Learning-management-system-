package controller;

import dao.QuizDAO;
import model.Question;
import model.Quiz;

import java.util.List;

public class QuizController {
    private QuizDAO quizDAO;
    
    public QuizController(QuizDAO quizDAO) {
        this.quizDAO = quizDAO;
    }
    
    public boolean createQuiz(Quiz quiz) {
        return quizDAO.createQuiz(quiz);
    }
    
    public List<Quiz> getQuizzesForCourse(int courseId) {
        return quizDAO.getQuizzesByCourse(courseId);
    }
    
    public boolean publishQuiz(int quizId) {
        return quizDAO.publishQuiz(quizId);
    }
    
    public int calculateScore(Quiz quiz, List<String> answers) {
        int score = 0;
        List<Question> questions = quiz.getQuestions();
        
        for (int i = 0; i < questions.size(); i++) {
            if (i < answers.size() && questions.get(i).isCorrect(answers.get(i))) {
                score += questions.get(i).getPoints();
            }
        }
        
        return score;
    }
    
    public double calculatePercentage(int score, Quiz quiz) {
        return ((double) score / quiz.getTotalPoints()) * 100;
    }
}