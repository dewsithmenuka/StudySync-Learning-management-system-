package controller;

import dao.CourseDAO;
import dao.EnrollmentDAO;
import dao.UserDAO; // Import UserDAO
import model.Course;
import model.StudentProgress;
import view.TeacherDashboardView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.util.List;

public class CourseController {
    private final CourseDAO courseDAO;
    private final EnrollmentDAO enrollmentDAO;
    private final UserDAO userDAO; // Added UserDAO
    private final TeacherDashboardView teacherDashboardView;

    public CourseController(CourseDAO courseDAO, EnrollmentDAO enrollmentDAO,
                          UserDAO userDAO, TeacherDashboardView teacherDashboardView) { // Updated constructor signature
        this.courseDAO = courseDAO;
        this.enrollmentDAO = enrollmentDAO;
        this.userDAO = userDAO; // Initialize UserDAO
        this.teacherDashboardView = teacherDashboardView;

        // Initialize data for current teacher (replace with actual logged-in teacher ID)
        int teacherId = 1; // Placeholder, should come from logged-in user
        loadCoursesForTeacher(teacherId);
        loadStudentProgress(teacherId, null);

        // Register all listeners
        registerListeners();
    }

    private void registerListeners() {
        teacherDashboardView.addCreateAssignmentListener(new CreateAssignmentListener());
        teacherDashboardView.addAddCourseListener(new AddCourseListener());
        teacherDashboardView.addEditCourseListener(new EditCourseListener());
        teacherDashboardView.addDeleteCourseListener(new DeleteCourseListener());
        teacherDashboardView.addRefreshProgressListener(new RefreshProgressListener());
    }

    private void loadCoursesForTeacher(int teacherId) {
        List<Course> courses = courseDAO.getCoursesByTeacher(teacherId);
        teacherDashboardView.displayCourses(courses);
    }

    private void loadStudentProgress(int teacherId, String courseFilter) {
        // Corrected method call, now that getStudentProgressByTeacher exists in EnrollmentDAO
        List<StudentProgress> progressList = enrollmentDAO.getStudentProgressByTeacher(teacherId, courseFilter);
        teacherDashboardView.displayStudentProgress(progressList);
    }

    // ActionListener implementations
    class CreateAssignmentListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedCourseId = teacherDashboardView.getSelectedCourseId();
            if (selectedCourseId != -1) {
                // Implement assignment creation logic here
            } else {
                showWarning("Please select a course first");
            }
        }
    }

    class AddCourseListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String title = JOptionPane.showInputDialog(teacherDashboardView, "Enter course title:");
            if (title != null && !title.trim().isEmpty()) {
                String description = JOptionPane.showInputDialog(teacherDashboardView, "Enter course description:");
                if (description != null) {
                    Course newCourse = new Course();
                    newCourse.setTitle(title.trim());
                    newCourse.setDescription(description.trim());
                    newCourse.setCreatedBy(1); // Replace with actual teacher ID

                    if (courseDAO.createCourse(newCourse)) {
                        showSuccess("Course added successfully!");
                        loadCoursesForTeacher(1); // Refresh list
                    } else {
                        showError("Failed to add course");
                    }
                }
            }
        }
    }

    class EditCourseListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedCourseId = teacherDashboardView.getSelectedCourseId();
            if (selectedCourseId != -1) {
                Course course = courseDAO.getCourseById(selectedCourseId);
                if (course != null) {
                    String newTitle = JOptionPane.showInputDialog(
                        teacherDashboardView, "Edit title:", course.getTitle());
                    if (newTitle != null && !newTitle.trim().isEmpty()) {
                        String newDesc = JOptionPane.showInputDialog(
                            teacherDashboardView, "Edit description:", course.getDescription());
                        if (newDesc != null) {
                            course.setTitle(newTitle.trim());
                            course.setDescription(newDesc.trim());
                            if (courseDAO.updateCourse(course)) {
                                showSuccess("Course updated successfully!");
                                loadCoursesForTeacher(1); // Refresh list
                            } else {
                                showError("Failed to update course");
                            }
                        }
                    }
                }
            } else {
                showWarning("Please select a course to edit");
            }
        }
    }

    class DeleteCourseListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            int selectedCourseId = teacherDashboardView.getSelectedCourseId();
            if (selectedCourseId != -1) {
                int confirm = JOptionPane.showConfirmDialog(teacherDashboardView,
                    "Delete this course?", "Confirm", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    if (courseDAO.deleteCourse(selectedCourseId)) {
                        showSuccess("Course deleted successfully!");
                        loadCoursesForTeacher(1); // Refresh list
                    } else {
                        showError("Failed to delete course");
                    }
                }
            } else {
                showWarning("Please select a course to delete");
            }
        }
    }

    class RefreshProgressListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String filter = teacherDashboardView.getSelectedCourseFilter();
            if ("All Courses".equals(filter)) filter = null;
            loadStudentProgress(1, filter); // Replace with actual teacher ID
        }
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(teacherDashboardView, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(teacherDashboardView, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showWarning(String message) {
        JOptionPane.showMessageDialog(teacherDashboardView, message, "Warning", JOptionPane.WARNING_MESSAGE);
    }
}
