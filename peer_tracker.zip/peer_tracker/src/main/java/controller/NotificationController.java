package controller;

import dao.NotificationDAO;
import model.Notification;

import java.util.List;

public class NotificationController {
    private NotificationDAO notificationDAO;
    
    public NotificationController(NotificationDAO notificationDAO) {
        this.notificationDAO = notificationDAO;
    }
    
    public void createNotification(int userId, Notification.Type type, 
                                 String message, String relatedEntityType, 
                                 int relatedEntityId) {
        Notification notification = new Notification();
        notification.setUserId(userId);
        notification.setType(type);
        notification.setMessage(message);
        notification.setRelatedEntityType(relatedEntityType);
        notification.setRelatedEntityId(relatedEntityId);
        notification.setCreatedAt(java.time.LocalDateTime.now());
        notification.setRead(false);
        
        notificationDAO.saveNotification(notification);
    }
    
    public List<Notification> getUnreadNotifications(int userId) {
        return notificationDAO.getUnreadNotifications(userId);
    }
    
    public void markAsRead(int notificationId) {
        notificationDAO.markAsRead(notificationId);
    }
    
    public void markAllAsRead(int userId) {
        List<Notification> unread = getUnreadNotifications(userId);
        for (Notification notification : unread) {
            markAsRead(notification.getNotificationId());
        }
    }
}