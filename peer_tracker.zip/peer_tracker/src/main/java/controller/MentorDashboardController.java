package controller;

import dao.MessageDAO;
import dao.UserDAO;
import dao.ResourceDAO; // New DAO
import dao.SessionDAO;   // New DAO
import model.Message;
import model.User;
import model.Resource; // New Model
import model.Session;  // New Model
import view.MentorDashboardView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.util.List;
import java.time.LocalDateTime;
import javax.swing.JFileChooser;
import java.io.File;
import javax.swing.JTextField; // Import JTextField
import javax.swing.JPanel;     // Import JPanel
import javax.swing.JLabel;     // Import JLabel
import javax.swing.JButton;    // Import JButton
import java.awt.GridLayout;    // Import GridLayout
import java.awt.BorderLayout;  // Import BorderLayout


public class MentorDashboardController {
    private MentorDashboardView mentorDashboardView;
    private UserDAO userDAO;
    private MessageDAO messageDAO;
    private ResourceDAO resourceDAO; // New DAO
    private SessionDAO sessionDAO;   // New DAO
    private int currentMentorId; // Assuming the logged-in mentor's ID

    public MentorDashboardController(MentorDashboardView mentorDashboardView, UserDAO userDAO,
                                   MessageDAO messageDAO, ResourceDAO resourceDAO, SessionDAO sessionDAO,
                                   int currentMentorId) {
        this.mentorDashboardView = mentorDashboardView;
        this.userDAO = userDAO;
        this.messageDAO = messageDAO;
        this.resourceDAO = resourceDAO;
        this.sessionDAO = sessionDAO;
        this.currentMentorId = currentMentorId;

        // Initialize data
        loadMentees(currentMentorId);
        loadResources(currentMentorId);
        loadSessions(currentMentorId);

        // Register listeners
        registerListeners();
    }

    private void registerListeners() {
        mentorDashboardView.addSendMessageListener(new SendMessageListener());
        mentorDashboardView.addScheduleSessionListener(new ScheduleSessionListener());
        mentorDashboardView.addViewProgressListener(new ViewProgressListener());
        mentorDashboardView.addShareResourceListener(new ShareResourceListener());

        // Resource management listeners
        mentorDashboardView.addAddResourceListener(new AddResourceListener());
        mentorDashboardView.addEditResourceListener(new EditResourceListener());
        mentorDashboardView.addDeleteResourceListener(new DeleteResourceListener());

        // Session management listeners
        mentorDashboardView.addAddSessionListener(new AddSessionListener());
        mentorDashboardView.addEditSessionListener(new EditSessionListener());
        mentorDashboardView.addDeleteSessionListener(new DeleteSessionListener());
    }

    private void loadMentees(int mentorId) {
        // This would typically involve a more complex query to get mentees
        // associated with this mentor, possibly through a mentorships table
        // For now, let's assume a simple way to get students who have this mentor's ID as their parent_id
        List<User> mentees = userDAO.getChildrenByParent(mentorId); // Reusing getChildrenByParent for mentor-mentee relationship
        mentorDashboardView.displayMentees(mentees);
    }

    private void loadResources(int mentorId) {
        List<Resource> resources = resourceDAO.getResourcesByMentor(mentorId);
        mentorDashboardView.displayResources(resources);
    }

    private void loadSessions(int mentorId) {
        List<Session> sessions = sessionDAO.getSessionsByMentor(mentorId);
        mentorDashboardView.displaySessions(sessions);
    }

    // Listener for Send Message (existing)
    class SendMessageListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int menteeId = mentorDashboardView.getSelectedMenteeId();
            if (menteeId != -1) {
                String messageContent = JOptionPane.showInputDialog(mentorDashboardView, "Enter message for mentee:");
                if (messageContent != null && !messageContent.trim().isEmpty()) {
                    Message message = new Message();
                    message.setSenderId(currentMentorId);
                    message.setReceiverId(menteeId);
                    message.setContent(messageContent.trim());

                    if (messageDAO.sendMessage(message)) {
                        JOptionPane.showMessageDialog(mentorDashboardView,
                            "Message sent successfully",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(mentorDashboardView,
                            "Failed to send message",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(mentorDashboardView,
                    "Please select a mentee first",
                    "No Mentee Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Listener for Schedule Session (existing, now with implementation)
    class ScheduleSessionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int menteeId = mentorDashboardView.getSelectedMenteeId();
            if (menteeId != -1) {
                // Open a dialog to get session details
                JTextField titleField = new JTextField();
                JTextField descriptionField = new JTextField();
                JTextField startTimeField = new JTextField("YYYY-MM-DD HH:MM");
                JTextField endTimeField = new JTextField("YYYY-MM-DD HH:MM");
                JTextField locationField = new JTextField();

                JPanel panel = new JPanel(new GridLayout(0, 2));
                panel.add(new JLabel("Title:"));
                panel.add(titleField);
                panel.add(new JLabel("Description:"));
                panel.add(descriptionField);
                panel.add(new JLabel("Start Time (YYYY-MM-DD HH:MM):"));
                panel.add(startTimeField);
                panel.add(new JLabel("End Time (YYYY-MM-DD HH:MM):"));
                panel.add(endTimeField);
                panel.add(new JLabel("Location:"));
                panel.add(locationField);

                int result = JOptionPane.showConfirmDialog(mentorDashboardView, panel, "Schedule New Session",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result == JOptionPane.OK_OPTION) {
                    try {
                        Session newSession = new Session();
                        newSession.setMentorId(currentMentorId);
                        newSession.setMenteeId(menteeId);
                        newSession.setTitle(titleField.getText());
                        newSession.setDescription(descriptionField.getText());
                        newSession.setStartTime(LocalDateTime.parse(startTimeField.getText(), java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
                        newSession.setEndTime(LocalDateTime.parse(endTimeField.getText(), java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")));
                        newSession.setLocation(locationField.getText());

                        if (sessionDAO.createSession(newSession)) {
                            JOptionPane.showMessageDialog(mentorDashboardView, "Session scheduled successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                            loadSessions(currentMentorId); // Refresh sessions list
                        } else {
                            JOptionPane.showMessageDialog(mentorDashboardView, "Failed to schedule session.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (java.time.format.DateTimeParseException ex) {
                        JOptionPane.showMessageDialog(mentorDashboardView, "Invalid date/time format. Please use YYYY-MM-DD HH:MM.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(mentorDashboardView,
                    "Please select a mentee first",
                    "No Mentee Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Listener for View Progress (placeholder)
    class ViewProgressListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int menteeId = mentorDashboardView.getSelectedMenteeId();
            if (menteeId != -1) {
                JOptionPane.showMessageDialog(mentorDashboardView, "Viewing progress for mentee ID: " + menteeId + " (To be implemented)", "View Progress", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(mentorDashboardView,
                    "Please select a mentee first",
                    "No Mentee Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Listener for Share Resource (placeholder)
    class ShareResourceListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int menteeId = mentorDashboardView.getSelectedMenteeId();
            if (menteeId != -1) {
                JOptionPane.showMessageDialog(mentorDashboardView, "Sharing resource with mentee ID: " + menteeId + " (To be implemented)", "Share Resource", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(mentorDashboardView,
                    "Please select a mentee first",
                    "No Mentee Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Resource Management Listeners
    class AddResourceListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JTextField titleField = new JTextField();
            JTextField descriptionField = new JTextField();
            JTextField filePathField = new JTextField();
            JButton browseButton = new JButton("Browse");

            browseButton.addActionListener(event -> {
                JFileChooser fileChooser = new JFileChooser();
                int returnValue = fileChooser.showOpenDialog(mentorDashboardView);
                if (returnValue == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    filePathField.setText(selectedFile.getAbsolutePath());
                }
            });

            JPanel panel = new JPanel(new GridLayout(0, 2));
            panel.add(new JLabel("Title:"));
            panel.add(titleField);
            panel.add(new JLabel("Description:"));
            panel.add(descriptionField);
            panel.add(new JLabel("File Path:"));
            JPanel filePanel = new JPanel(new BorderLayout());
            filePanel.add(filePathField, BorderLayout.CENTER);
            filePanel.add(browseButton, BorderLayout.EAST);
            panel.add(filePanel);

            int result = JOptionPane.showConfirmDialog(mentorDashboardView, panel, "Add New Resource",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

            if (result == JOptionPane.OK_OPTION) {
                Resource newResource = new Resource();
                newResource.setMentorId(currentMentorId);
                newResource.setTitle(titleField.getText());
                newResource.setDescription(descriptionField.getText());
                newResource.setFilePath(filePathField.getText());
                newResource.setUploadDate(LocalDateTime.now());

                if (resourceDAO.createResource(newResource)) {
                    JOptionPane.showMessageDialog(mentorDashboardView, "Resource added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadResources(currentMentorId); // Refresh resources list
                } else {
                    JOptionPane.showMessageDialog(mentorDashboardView, "Failed to add resource.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    class EditResourceListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedResourceId = mentorDashboardView.getSelectedResourceId();
            if (selectedResourceId != -1) {
                Resource resourceToEdit = resourceDAO.getResourceById(selectedResourceId);
                if (resourceToEdit != null) {
                    JTextField titleField = new JTextField(resourceToEdit.getTitle());
                    JTextField descriptionField = new JTextField(resourceToEdit.getDescription());
                    JTextField filePathField = new JTextField(resourceToEdit.getFilePath());
                    JButton browseButton = new JButton("Browse");

                    browseButton.addActionListener(event -> {
                        JFileChooser fileChooser = new JFileChooser();
                        int returnValue = fileChooser.showOpenDialog(mentorDashboardView);
                        if (returnValue == JFileChooser.APPROVE_OPTION) {
                            File selectedFile = fileChooser.getSelectedFile();
                            filePathField.setText(selectedFile.getAbsolutePath());
                        }
                    });

                    JPanel panel = new JPanel(new GridLayout(0, 2));
                    panel.add(new JLabel("Title:"));
                    panel.add(titleField);
                    panel.add(new JLabel("Description:"));
                    panel.add(descriptionField);
                    panel.add(new JLabel("File Path:"));
                    JPanel filePanel = new JPanel(new BorderLayout());
                    filePanel.add(filePathField, BorderLayout.CENTER);
                    filePanel.add(browseButton, BorderLayout.EAST);
                    panel.add(filePanel);

                    int result = JOptionPane.showConfirmDialog(mentorDashboardView, panel, "Edit Resource",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        resourceToEdit.setTitle(titleField.getText());
                        resourceToEdit.setDescription(descriptionField.getText());
                        resourceToEdit.setFilePath(filePathField.getText());

                        if (resourceDAO.updateResource(resourceToEdit)) {
                            JOptionPane.showMessageDialog(mentorDashboardView, "Resource updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                            loadResources(currentMentorId); // Refresh resources list
                        } else {
                            JOptionPane.showMessageDialog(mentorDashboardView, "Failed to update resource.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(mentorDashboardView, "Resource not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(mentorDashboardView, "Please select a resource to edit.", "No Resource Selected", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    class DeleteResourceListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedResourceId = mentorDashboardView.getSelectedResourceId();
            if (selectedResourceId != -1) {
                int confirm = JOptionPane.showConfirmDialog(mentorDashboardView,
                    "Are you sure you want to delete this resource?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    if (resourceDAO.deleteResource(selectedResourceId)) {
                        JOptionPane.showMessageDialog(mentorDashboardView, "Resource deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        loadResources(currentMentorId); // Refresh resources list
                    } else {
                        JOptionPane.showMessageDialog(mentorDashboardView, "Failed to delete resource.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(mentorDashboardView, "Please select a resource to delete.", "No Resource Selected", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Session Management Listeners
    class AddSessionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // This is similar to ScheduleSessionListener but allows selecting mentee
            // or creating a general session. For simplicity, let's assume it's for a specific mentee.
            // A more robust solution would involve a mentee selection dropdown.
            String menteeIdStr = JOptionPane.showInputDialog(mentorDashboardView, "Enter Mentee ID for session:");
            if (menteeIdStr == null || menteeIdStr.trim().isEmpty()) return;

            try {
                int menteeId = Integer.parseInt(menteeIdStr.trim());
                if (userDAO.getUserById(menteeId) == null || !userDAO.getUserById(menteeId).getRole().equals("Student")) {
                    JOptionPane.showMessageDialog(mentorDashboardView, "Invalid Mentee ID or not a student.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                JTextField titleField = new JTextField();
                JTextField descriptionField = new JTextField();
                JTextField startTimeField = new JTextField("YYYY-MM-DD HH:MM");
                JTextField endTimeField = new JTextField("YYYY-MM-DD HH:MM");
                JTextField locationField = new JTextField();

                JPanel panel = new JPanel(new GridLayout(0, 2));
                panel.add(new JLabel("Title:"));
                panel.add(titleField);
                panel.add(new JLabel("Description:"));
                panel.add(descriptionField);
                panel.add(new JLabel("Start Time (YYYY-MM-DD HH:MM):"));
                panel.add(startTimeField);
                panel.add(new JLabel("End Time (YYYY-MM-DD HH:MM):"));
                panel.add(endTimeField);
                panel.add(new JLabel("Location:"));
                panel.add(locationField);

                int result = JOptionPane.showConfirmDialog(mentorDashboardView, panel, "Add New Session",
                    JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                if (result == JOptionPane.OK_OPTION) {
                    Session newSession = new Session();
                    newSession.setMentorId(currentMentorId);
                    newSession.setMenteeId(menteeId);
                    newSession.setTitle(titleField.getText());
                    newSession.setDescription(descriptionField.getText());
                    newSession.setStartTime(LocalDateTime.parse(startTimeField.getText(), java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-DD HH:mm")));
                    newSession.setEndTime(LocalDateTime.parse(endTimeField.getText(), java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-DD HH:mm")));
                    newSession.setLocation(locationField.getText());

                    if (sessionDAO.createSession(newSession)) {
                        JOptionPane.showMessageDialog(mentorDashboardView, "Session added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        loadSessions(currentMentorId); // Refresh sessions list
                    } else {
                        JOptionPane.showMessageDialog(mentorDashboardView, "Failed to add session.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(mentorDashboardView, "Invalid Mentee ID. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (java.time.format.DateTimeParseException ex) {
                JOptionPane.showMessageDialog(mentorDashboardView, "Invalid date/time format. Please use YYYY-MM-DD HH:MM.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    class EditSessionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedSessionId = mentorDashboardView.getSelectedSessionId();
            if (selectedSessionId != -1) {
                Session sessionToEdit = sessionDAO.getSessionById(selectedSessionId);
                if (sessionToEdit != null) {
                    JTextField titleField = new JTextField(sessionToEdit.getTitle());
                    JTextField descriptionField = new JTextField(sessionToEdit.getDescription());
                    JTextField startTimeField = new JTextField(sessionToEdit.getStartTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-DD HH:mm")));
                    JTextField endTimeField = new JTextField(sessionToEdit.getEndTime().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-DD HH:mm")));
                    JTextField locationField = new JTextField(sessionToEdit.getLocation());

                    JPanel panel = new JPanel(new GridLayout(0, 2));
                    panel.add(new JLabel("Title:"));
                    panel.add(titleField);
                    panel.add(new JLabel("Description:"));
                    panel.add(descriptionField);
                    panel.add(new JLabel("Start Time (YYYY-MM-DD HH:MM):"));
                    panel.add(startTimeField);
                    panel.add(new JLabel("End Time (YYYY-MM-DD HH:MM):"));
                    panel.add(endTimeField);
                    panel.add(new JLabel("Location:"));
                    panel.add(locationField);

                    int result = JOptionPane.showConfirmDialog(mentorDashboardView, panel, "Edit Session",
                        JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

                    if (result == JOptionPane.OK_OPTION) {
                        try {
                            sessionToEdit.setTitle(titleField.getText());
                            sessionToEdit.setDescription(descriptionField.getText());
                            sessionToEdit.setStartTime(LocalDateTime.parse(startTimeField.getText(), java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-DD HH:mm")));
                            sessionToEdit.setEndTime(LocalDateTime.parse(endTimeField.getText(), java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-DD HH:mm")));
                            sessionToEdit.setLocation(locationField.getText());

                            if (sessionDAO.updateSession(sessionToEdit)) {
                                JOptionPane.showMessageDialog(mentorDashboardView, "Session updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                                loadSessions(currentMentorId); // Refresh sessions list
                            } else {
                                JOptionPane.showMessageDialog(mentorDashboardView, "Failed to update session.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } catch (java.time.format.DateTimeParseException ex) {
                            JOptionPane.showMessageDialog(mentorDashboardView, "Invalid date/time format. Please use YYYY-MM-DD HH:MM.", "Input Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(mentorDashboardView, "Session not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(mentorDashboardView, "Please select a session to edit.", "No Session Selected", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    class DeleteSessionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedSessionId = mentorDashboardView.getSelectedSessionId();
            if (selectedSessionId != -1) {
                int confirm = JOptionPane.showConfirmDialog(mentorDashboardView,
                    "Are you sure you want to delete this session?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    if (sessionDAO.deleteSession(selectedSessionId)) {
                        JOptionPane.showMessageDialog(mentorDashboardView, "Session deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        loadSessions(currentMentorId); // Refresh sessions list
                    } else {
                        JOptionPane.showMessageDialog(mentorDashboardView, "Failed to delete session.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(mentorDashboardView, "Please select a session to delete.", "No Session Selected", JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}
