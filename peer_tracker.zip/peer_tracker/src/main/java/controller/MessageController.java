package controller;

import dao.CourseDAO; // Added
import dao.EnrollmentDAO; // Added
import dao.MessageDAO;
import dao.UserDAO;
import model.Course; // Added
import model.Enrollment; // Added
import model.Message;
import model.User;
import view.MentorDashboardView;
import view.ParentDashboardView;
import view.StudentDashboardView;
import view.TeacherDashboardView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.util.List;
import java.util.Set; // Added
import java.util.HashSet; // Added
import javax.swing.JComboBox; // Added
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class MessageController {
    private MessageDAO messageDAO;
    private UserDAO userDAO;
    private EnrollmentDAO enrollmentDAO; // Added
    private CourseDAO courseDAO; // Added
    private StudentDashboardView studentDashboardView;
    private TeacherDashboardView teacherDashboardView;
    private MentorDashboardView mentorDashboardView;
    private ParentDashboardView parentDashboardView;
    private int currentUserId; // To store the logged-in user's ID

    public MessageController(MessageDAO messageDAO, UserDAO userDAO,
                            StudentDashboardView studentDashboardView) {
        this.messageDAO = messageDAO;
        this.userDAO = userDAO;
        this.studentDashboardView = studentDashboardView;
        // Implement as needed
    }

    public MessageController(MessageDAO messageDAO, UserDAO userDAO,
                            TeacherDashboardView teacherDashboardView) {
        this.messageDAO = messageDAO;
        this.userDAO = userDAO;
        this.teacherDashboardView = teacherDashboardView;
        // Implement as needed
    }

    public MessageController(MessageDAO messageDAO, UserDAO userDAO,
                            MentorDashboardView mentorDashboardView) {
        this.messageDAO = messageDAO;
        this.userDAO = userDAO;
        this.mentorDashboardView = mentorDashboardView;
        mentorDashboardView.addSendMessageListener(new SendMessageListener());
    }

    public MessageController(MessageDAO messageDAO, UserDAO userDAO,
                            ParentDashboardView parentDashboardView, int currentUserId) {
        this.messageDAO = messageDAO;
        this.userDAO = userDAO;
        this.enrollmentDAO = new EnrollmentDAO(); // Initialize
        this.courseDAO = new CourseDAO(); // Initialize
        this.parentDashboardView = parentDashboardView;
        this.currentUserId = currentUserId; // Set the parent's ID
        this.parentDashboardView.setLoggedInUserId(currentUserId); // Set for view to distinguish sender

        // Register listeners for Parent Dashboard
        parentDashboardView.addContactTeacherListener(new ContactTeacherListener());
        parentDashboardView.addSendMessageListener(new ParentSendMessageListener());
        parentDashboardView.addTeacherSelectionListener(new TeacherSelectionListener());

        // Load initial data for messages tab
        loadTeachersForParent(currentUserId);
    }

    // Method to load teachers for the parent's children
    private void loadTeachersForParent(int parentId) {
        Set<User> teachers = new HashSet<>();
        List<User> children = userDAO.getChildrenByParent(parentId);
        for (User child : children) {
            List<Enrollment> enrollments = enrollmentDAO.getEnrollmentsByStudent(child.getUserId());
            for (Enrollment enrollment : enrollments) {
                Course course = courseDAO.getCourseById(enrollment.getCourseId());
                if (course != null) {
                    User teacher = userDAO.getUserById(course.getCreatedBy());
                    if (teacher != null && teacher.getRole().equals("Teacher")) {
                        teachers.add(teacher);
                    }
                }
            }
        }
        parentDashboardView.displayTeachers(teachers.stream().toList());
    }

    class SendMessageListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // This listener is for MentorDashboardView, already implemented in MentorDashboardController
            // The logic here is a placeholder from the original context.
            int menteeId = mentorDashboardView.getSelectedMenteeId();
            if (menteeId != -1) {
                String messageContent = JOptionPane.showInputDialog(mentorDashboardView, "Enter message for mentee:");
                if (messageContent != null && !messageContent.trim().isEmpty()) {
                    Message message = new Message();
                    // message.setSenderId(mentorId); // This should be currentUserId
                    message.setSenderId(currentUserId); // Assuming currentUserId is set for mentor
                    message.setReceiverId(menteeId);
                    message.setContent(messageContent.trim());

                    boolean success = messageDAO.sendMessage(message);
                    if (success) {
                        JOptionPane.showMessageDialog(mentorDashboardView,
                            "Message sent successfully",
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(mentorDashboardView,
                            "Failed to send message",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(mentorDashboardView,
                    "Please select a mentee first",
                    "No Mentee Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    class ContactTeacherListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int childId = parentDashboardView.getSelectedChildId();
            if (childId != -1) {
                // Get child's teachers
                Set<User> teachers = new HashSet<>();
                List<Enrollment> enrollments = enrollmentDAO.getEnrollmentsByStudent(childId);
                for (Enrollment enrollment : enrollments) {
                    Course course = courseDAO.getCourseById(enrollment.getCourseId());
                    if (course != null) {
                        User teacher = userDAO.getUserById(course.getCreatedBy());
                        if (teacher != null && teacher.getRole().equals("Teacher")) {
                            teachers.add(teacher);
                        }
                    }
                }

                if (teachers.isEmpty()) {
                    JOptionPane.showMessageDialog(parentDashboardView,
                        "No teachers found for the selected child's courses.",
                        "No Teachers",
                        JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                // Allow parent to select a teacher
                JComboBox<User> teacherComboBox = new JComboBox<>(teachers.toArray(new User[0]));
                int result = JOptionPane.showConfirmDialog(parentDashboardView,
                    teacherComboBox, "Select Teacher to Contact", JOptionPane.OK_CANCEL_OPTION);

                if (result == JOptionPane.OK_OPTION) {
                    User selectedTeacher = (User) teacherComboBox.getSelectedItem();
                    if (selectedTeacher != null) {
                        String messageContent = JOptionPane.showInputDialog(parentDashboardView,
                            "Enter message for " + selectedTeacher.getName() + ":");

                        if (messageContent != null && !messageContent.trim().isEmpty()) {
                            Message message = new Message();
                            message.setSenderId(currentUserId); // Parent's ID
                            message.setReceiverId(selectedTeacher.getUserId());
                            message.setContent(messageContent.trim());

                            boolean success = messageDAO.sendMessage(message);
                            if (success) {
                                JOptionPane.showMessageDialog(parentDashboardView,
                                    "Message sent successfully to " + selectedTeacher.getName(),
                                    "Success",
                                    JOptionPane.INFORMATION_MESSAGE);
                            } else {
                                JOptionPane.showMessageDialog(parentDashboardView,
                                    "Failed to send message",
                                    "Error",
                                    JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                }
            } else {
                JOptionPane.showMessageDialog(parentDashboardView,
                    "Please select a child first to contact their teacher",
                    "No Child Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // New Listener for sending messages from the dedicated message tab
    class ParentSendMessageListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            User selectedTeacher = parentDashboardView.getSelectedTeacher();
            if (selectedTeacher != null) {
                String messageContent = parentDashboardView.getMessageInput();
                if (messageContent != null && !messageContent.trim().isEmpty()) {
                    Message message = new Message();
                    message.setSenderId(currentUserId);
                    message.setReceiverId(selectedTeacher.getUserId());
                    message.setContent(messageContent.trim());

                    boolean success = messageDAO.sendMessage(message);
                    if (success) {
                        JOptionPane.showMessageDialog(parentDashboardView,
                            "Message sent successfully to " + selectedTeacher.getName(),
                            "Success",
                            JOptionPane.INFORMATION_MESSAGE);
                        parentDashboardView.clearMessageInput();
                        // Refresh conversation
                        parentDashboardView.displayConversation(messageDAO.getConversation(currentUserId, selectedTeacher.getUserId()));
                    } else {
                        JOptionPane.showMessageDialog(parentDashboardView,
                            "Failed to send message",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(parentDashboardView,
                        "Message cannot be empty.",
                        "Input Error",
                        JOptionPane.WARNING_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(parentDashboardView,
                    "Please select a teacher to send a message.",
                    "No Teacher Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // New Listener for selecting a teacher in the message tab
    class TeacherSelectionListener implements ListSelectionListener {
        @Override
        public void valueChanged(ListSelectionEvent e) {
            if (!e.getValueIsAdjusting()) {
                User selectedTeacher = parentDashboardView.getSelectedTeacher();
                if (selectedTeacher != null) {
                    List<Message> conversation = messageDAO.getConversation(currentUserId, selectedTeacher.getUserId());
                    parentDashboardView.displayConversation(conversation);
                } else {
                    parentDashboardView.displayConversation(List.of()); // Clear conversation if no teacher selected
                }
            }
        }
    }

    // Methods for message management
    public boolean sendMessage(Message message) {
        return messageDAO.sendMessage(message);
    }

    public List<Message> getConversation(int userId1, int userId2) {
        return messageDAO.getConversation(userId1, userId2);
    }

    public List<Message> getUnreadMessages(int userId) {
        return messageDAO.getUnreadMessages(userId);
    }

    public User getUserById(int userId) {
        return userDAO.getUserById(userId);
    }
}
