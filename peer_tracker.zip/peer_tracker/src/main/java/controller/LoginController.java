package controller;

import dao.AssignmentDAO; // Added
import dao.CourseDAO;     // Added
import dao.EnrollmentDAO; // Added
import dao.MessageDAO;
import dao.NotificationDAO; // Added
import dao.ResourceDAO;
import dao.SessionDAO;
import dao.StudyGroupDAO; // Added
import dao.SubmissionDAO; // Added
import dao.UserDAO;
import model.User;
import view.LoginView;
import view.MentorDashboardView;
import view.ParentDashboardView;
import view.RegisterView;
import view.StudentDashboardView;
import view.TeacherDashboardView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class LoginController {
    private LoginView loginView;
    private RegisterView registerView; // This might be null if not used directly in LoginController's constructor
    private UserDAO userDAO;

    public LoginController(LoginView loginView, UserDAO userDAO) {
        this.loginView = loginView;
        this.userDAO = userDAO;

        loginView.addLoginListener(new LoginListener());
        loginView.addRegisterListener(new RegisterListener());
    }

    class LoginListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String email = loginView.getEmail();
            String password = loginView.getPassword();

            User user = userDAO.getUserByCredentials(email, password);

            if (user != null) {
                loginView.dispose(); // Close login window
                redirectToDashboard(user);
            } else {
                loginView.showErrorMessage("Invalid email or password");
            }
        }
    }

    class RegisterListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            loginView.setVisible(false); // Hide login window
            RegisterView registerView = new RegisterView();
            new RegisterController(registerView, userDAO, loginView); // Pass loginView to RegisterController
            registerView.setVisible(true);
        }
    }

    private void redirectToDashboard(User user) {
        switch (user.getRole()) {
            case "Admin":
                // AdminDashboardView adminDashboardView = new AdminDashboardView();
                // new AdminDashboardController(adminDashboardView, userDAO);
                // adminDashboardView.setVisible(true);
                JOptionPane.showMessageDialog(loginView, "Admin Dashboard (Not fully implemented)", "Login Success", JOptionPane.INFORMATION_MESSAGE);
                break;
            case "Teacher":
                TeacherDashboardView teacherDashboardView = new TeacherDashboardView();
                // Assuming these DAOs are needed for TeacherDashboardController
                new CourseController(new dao.CourseDAO(), new dao.EnrollmentDAO(), userDAO, teacherDashboardView);
                new AssignmentController(new dao.AssignmentDAO(), new dao.SubmissionDAO(), teacherDashboardView);
                new TeacherDashboardController(teacherDashboardView, userDAO, new dao.CourseDAO(), new dao.EnrollmentDAO());
                teacherDashboardView.setVisible(true);
                break;
            case "Student":
                StudentDashboardView studentDashboardView = new StudentDashboardView();
                // Instantiate all DAOs required by StudentDashboardController
                AssignmentDAO assignmentDAO_student = new AssignmentDAO();
                SubmissionDAO submissionDAO_student = new SubmissionDAO();
                CourseDAO courseDAO_student = new CourseDAO();
                EnrollmentDAO enrollmentDAO_student = new EnrollmentDAO();
                StudyGroupDAO studyGroupDAO_student = new StudyGroupDAO();
                UserDAO userDAO_student = new UserDAO();
                MessageDAO messageDAO_student = new MessageDAO();
                NotificationDAO notificationDAO_student = new NotificationDAO();

                new StudentDashboardController(studentDashboardView, assignmentDAO_student, submissionDAO_student,
                                               courseDAO_student, enrollmentDAO_student, studyGroupDAO_student,
                                               userDAO_student, messageDAO_student, notificationDAO_student, user.getUserId());
                studentDashboardView.setVisible(true);
                break;
            case "Mentor":
                MentorDashboardView mentorDashboardView = new MentorDashboardView();
                MessageDAO messageDAO_mentor = new MessageDAO();
                ResourceDAO resourceDAO_mentor = new ResourceDAO();
                SessionDAO sessionDAO_mentor = new SessionDAO();
                new MentorDashboardController(mentorDashboardView, userDAO, messageDAO_mentor, resourceDAO_mentor, sessionDAO_mentor, user.getUserId());
                mentorDashboardView.setVisible(true);
                break;
            case "Parent":
                ParentDashboardView parentDashboardView = new ParentDashboardView();
                MessageDAO messageDAO_parent = new MessageDAO();
                // Pass the logged-in parent's ID to the controllers
                new MessageController(messageDAO_parent, userDAO, parentDashboardView, user.getUserId());
                new ParentChildController(userDAO, parentDashboardView, user.getUserId()); // Pass parent ID here
                parentDashboardView.setVisible(true);
                break;
            default:
                loginView.showErrorMessage("Unknown user role");
                loginView.setVisible(true);
        }
    }
}
