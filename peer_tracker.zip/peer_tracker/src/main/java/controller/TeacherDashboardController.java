package controller;

import dao.CourseDAO;
import dao.EnrollmentDAO;
import dao.UserDAO;
import model.Course;
import model.User;
import view.TeacherDashboardView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;

public class TeacherDashboardController {
    private TeacherDashboardView teacherDashboardView;
    private UserDAO userDAO;
    private CourseDAO courseDAO;
    private EnrollmentDAO enrollmentDAO;

    public TeacherDashboardController(TeacherDashboardView teacherDashboardView, UserDAO userDAO, CourseDAO courseDAO, EnrollmentDAO enrollmentDAO) {
        this.teacherDashboardView = teacherDashboardView;
        this.userDAO = userDAO;
        this.courseDAO = courseDAO;
        this.enrollmentDAO = enrollmentDAO;

        // Add listeners for student management features
        teacherDashboardView.addSearchStudentsListener(new SearchStudentsListener());
        teacherDashboardView.addAddStudentToCourseListener(new AddStudentToCourseListener());
    }

    class SearchStudentsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String searchTerm = teacherDashboardView.getStudentSearchTerm();
            if (searchTerm.isEmpty()) {
                JOptionPane.showMessageDialog(teacherDashboardView, "Please enter a search term.", "Search Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            List<User> students = userDAO.searchUsers(searchTerm);
            // Filter to only show students
            students.removeIf(user -> !user.getRole().equals("Student"));
            teacherDashboardView.displaySearchResults(students);
        }
    }

    class AddStudentToCourseListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int selectedCourseId = teacherDashboardView.getSelectedCourseId();
            int selectedStudentId = teacherDashboardView.getSelectedStudentIdFromSearchResults();

            if (selectedCourseId == -1) {
                JOptionPane.showMessageDialog(teacherDashboardView, "Please select a course from 'My Courses' tab first.", "Selection Error", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (selectedStudentId == -1) {
                JOptionPane.showMessageDialog(teacherDashboardView, "Please select a student from the search results first.", "Selection Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Check if student is already enrolled in the course
            List<model.Enrollment> enrollments = enrollmentDAO.getEnrollmentsByStudent(selectedStudentId);
            boolean alreadyEnrolled = enrollments.stream().anyMatch(enrollment -> enrollment.getCourseId() == selectedCourseId);

            if (alreadyEnrolled) {
                JOptionPane.showMessageDialog(teacherDashboardView, "Student is already enrolled in this course.", "Enrollment Info", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            // Perform enrollment
            boolean success = enrollmentDAO.enrollStudent(selectedStudentId, selectedCourseId);

            if (success) {
                JOptionPane.showMessageDialog(teacherDashboardView, "Student successfully added to the course!", "Success", JOptionPane.INFORMATION_MESSAGE);
                // Optionally refresh the courses table to show updated student count
                // For simplicity, we'll just show a success message.
                // To update student count, you'd need to fetch and update the course list again.
                // int teacherId = 1; // Placeholder, get actual teacher ID
                // teacherDashboardView.displayCourses(courseDAO.getCoursesByTeacher(teacherId));
            } else {
                JOptionPane.showMessageDialog(teacherDashboardView, "Failed to add student to the course.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
