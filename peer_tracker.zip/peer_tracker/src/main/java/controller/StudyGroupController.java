package controller;

import dao.NotificationDAO;
import dao.StudyGroupDAO;
import dao.UserDAO;
import model.Notification;
import model.StudyGroup;
import model.User;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.List;

public class StudyGroupController {
    private StudyGroupDAO studyGroupDAO;
    private UserDAO userDAO;
    private NotificationDAO notificationDAO;

    public StudyGroupController(StudyGroupDAO studyGroupDAO, UserDAO userDAO,
                              NotificationDAO notificationDAO) {
        this.studyGroupDAO = studyGroupDAO;
        this.userDAO = userDAO;
        this.notificationDAO = notificationDAO;
    }
    
    public List<StudyGroup> getGroupsForUser(int userId) {
    return studyGroupDAO.getGroupsForUser(userId);
}


    public boolean createStudyGroup(String name, String description, int creatorId,
                                  List<Integer> memberIds, String meetingSchedule,
                                  Integer courseId) {
        StudyGroup group = new StudyGroup();
        group.setName(name);
        group.setDescription(description);
        group.setCreatorId(creatorId);
        group.setMeetingSchedule(meetingSchedule);
        group.setCourseId(courseId);
        group.setCreatedAt(LocalDateTime.now());

        if (studyGroupDAO.createStudyGroup(group.getName(), group.getDescription(), 
                                            group.getCreatorId(), memberIds, 
                                            group.getMeetingSchedule(), group.getCourseId())) {
            // After creating the group, its ID should be set in the 'group' object by the DAO
            // Now add members
            for (int memberId : memberIds) {
                studyGroupDAO.addMemberToGroup(group.getGroupId(), memberId);

                // Notify each member
                User creator = userDAO.getUserById(creatorId);
                Notification notification = new Notification();
                notification.setUserId(memberId);
                notification.setType(Notification.Type.STUDY_GROUP);
                notification.setMessage("You've been added to study group '" + name + "' by " + creator.getName());
                notification.setRelatedEntityType("StudyGroup");
                notification.setRelatedEntityId(group.getGroupId());
                notificationDAO.saveNotification(notification);
            }
            return true;
        }
        return false;
    }
}
