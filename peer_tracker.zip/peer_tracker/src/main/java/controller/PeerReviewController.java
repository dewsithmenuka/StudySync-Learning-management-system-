package controller;

import dao.PeerReviewDAO;
import dao.SubmissionDAO;
import model.PeerReview;
import view.StudentDashboardView;
import view.TeacherDashboardView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.util.List;

public class PeerReviewController {
    private PeerReviewDAO peerReviewDAO;
    private SubmissionDAO submissionDAO;
    private TeacherDashboardView teacherDashboardView;
    private StudentDashboardView studentDashboardView;
    
    public PeerReviewController(PeerReviewDAO peerReviewDAO, SubmissionDAO submissionDAO,
                               TeacherDashboardView teacherDashboardView) {
        this.peerReviewDAO = peerReviewDAO;
        this.submissionDAO = submissionDAO;
        this.teacherDashboardView = teacherDashboardView;
        
        // Add action listeners for teacher dashboard
        teacherDashboardView.addManagePeerReviewsListener(new ManagePeerReviewsListener());
    }
    
    public PeerReviewController(PeerReviewDAO peerReviewDAO, SubmissionDAO submissionDAO,
                               StudentDashboardView studentDashboardView) {
        this.peerReviewDAO = peerReviewDAO;
        this.submissionDAO = submissionDAO;
        this.studentDashboardView = studentDashboardView;
        
        // Add action listeners for student dashboard
        studentDashboardView.addViewPeerReviewsListener(new ViewPeerReviewsListener());
    }
    
    class ManagePeerReviewsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int assignmentId = teacherDashboardView.getSelectedAssignmentId();
            if (assignmentId != -1) {
                // Open peer review management interface
                // Implement peer review assignment logic
            } else {
                JOptionPane.showMessageDialog(teacherDashboardView, 
                    "Please select an assignment first", 
                    "No Assignment Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class ViewPeerReviewsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int assignmentId = studentDashboardView.getSelectedAssignmentId();
            if (assignmentId != -1) {
                // Open peer reviews view
                // Get submission for this assignment and student
                // Get reviews for that submission
                // Display reviews to student
            } else {
                JOptionPane.showMessageDialog(studentDashboardView, 
                    "Please select an assignment first", 
                    "No Assignment Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    // Methods for peer review management
    public boolean createPeerReview(PeerReview peerReview) {
        return peerReviewDAO.createPeerReview(peerReview);
    }
    
    public List<PeerReview> getReviewsForSubmission(int submissionId) {
        return peerReviewDAO.getReviewsBySubmission(submissionId);
    }
    
    public List<PeerReview> getReviewsByReviewer(int reviewerId) {
        return peerReviewDAO.getReviewsByReviewer(reviewerId);
    }
    
    public double getAverageRating(int submissionId) {
        return peerReviewDAO.getAverageRating(submissionId);
    }
}