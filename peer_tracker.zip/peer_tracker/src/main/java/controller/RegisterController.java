// MultipleFiles/RegisterController.java
package controller;

import dao.UserDAO;
import model.User;
import view.RegisterView;
import view.LoginView; // Import LoginView

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class RegisterController {
    private RegisterView registerView;
    private UserDAO userDAO;
    private LoginView loginView; // Add a field to hold the LoginView reference

    // Modify the constructor to accept LoginView
    public RegisterController(RegisterView registerView, UserDAO userDAO, LoginView loginView) {
        this.registerView = registerView;
        this.userDAO = userDAO;
        this.loginView = loginView; // Store the LoginView reference
        
        // Add action listeners
        registerView.addRegisterListener(new RegisterListener());
        registerView.addCancelListener(new CancelListener());
    }

    class RegisterListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = registerView.getName();
            String email = registerView.getEmail();
            String password = registerView.getPassword();
            String confirmPassword = registerView.getConfirmPassword();
            String role = registerView.getRole();
            String phone = registerView.getPhone();
            
            // Validate inputs
            if (name.isEmpty() || email.isEmpty() || password.isEmpty() || 
                confirmPassword.isEmpty() || phone.isEmpty()) {
                registerView.showErrorMessage("All fields are required");
                return;
            }
            
            if (!password.equals(confirmPassword)) {
                registerView.showErrorMessage("Passwords do not match");
                return;
            }
            
            if (password.length() < 6) {
                registerView.showErrorMessage("Password must be at least 6 characters");
                return;
            }
            
            // Create new user
            User newUser = new User();
            newUser.setName(name);
            newUser.setEmail(email);
            newUser.setPassword(password);
            newUser.setRole(role);
            newUser.setPhone(phone);
            newUser.setActive(true);
            
            // Save to database
            boolean success = userDAO.createUser(newUser);
            if (success) {
                registerView.showSuccessMessage("Registration successful! You can now login.");
                registerView.dispose(); // Close the registration window
                if (loginView != null) { // Check if loginView reference exists
                    loginView.setVisible(true); // Make the login window visible again
                }
            } else {
                registerView.showErrorMessage("Registration failed. Email may already be in use.");
            }
        }
    }

    class CancelListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            registerView.dispose(); // Close the registration window
            if (loginView != null) { // Check if loginView reference exists
                loginView.setVisible(true); // Make the login window visible again
            }
        }
    }
}
