package controller;

import dao.AssignmentDAO;
import dao.SubmissionDAO;
import model.Assignment;
import model.Submission;
import view.StudentDashboardView;
import view.TeacherDashboardView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.util.List;

public class AssignmentController {
    private AssignmentDAO assignmentDAO;
    private SubmissionDAO submissionDAO;
    private TeacherDashboardView teacherDashboardView;
    private StudentDashboardView studentDashboardView;
    
    public AssignmentController(AssignmentDAO assignmentDAO, SubmissionDAO submissionDAO,
                               TeacherDashboardView teacherDashboardView) {
        this.assignmentDAO = assignmentDAO;
        this.submissionDAO = submissionDAO;
        this.teacherDashboardView = teacherDashboardView;
        
        // Add action listeners for teacher dashboard
        teacherDashboardView.addCreateAssignmentListener(new CreateAssignmentListener());
        teacherDashboardView.addGradeAssignmentsListener(new GradeAssignmentsListener());
        teacherDashboardView.addViewSubmissionsListener(new ViewSubmissionsListener());
    }
    
    public AssignmentController(AssignmentDAO assignmentDAO, SubmissionDAO submissionDAO,
                               StudentDashboardView studentDashboardView) {
        this.assignmentDAO = assignmentDAO;
        this.submissionDAO = submissionDAO;
        this.studentDashboardView = studentDashboardView;
        
        // Add action listeners for student dashboard
        studentDashboardView.addSubmitAssignmentListener(new SubmitAssignmentListener());
    }
    
    class CreateAssignmentListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int courseId = teacherDashboardView.getSelectedCourseId();
            if (courseId != -1) {
                // Open assignment creation dialog
                // Implement assignment creation logic
                // Assignment assignment = new Assignment();
                // assignment.setCourseId(courseId);
                // assignment.setTitle(title);
                // assignment.setDescription(description);
                // assignment.setDueDate(dueDate);
                // assignment.setCreatedBy(teacherId);
                
                // boolean success = assignmentDAO.createAssignment(assignment);
                // if (success) {
                //     JOptionPane.showMessageDialog(teacherDashboardView, 
                //         "Assignment created successfully", 
                //         "Success", 
                //         JOptionPane.INFORMATION_MESSAGE);
                //     loadAssignmentsForTeacher(teacherId);
                // }
            } else {
                JOptionPane.showMessageDialog(teacherDashboardView, 
                    "Please select a course first", 
                    "No Course Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class GradeAssignmentsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int assignmentId = teacherDashboardView.getSelectedAssignmentId();
            if (assignmentId != -1) {
                // Open grading interface
                // List<Submission> submissions = submissionDAO.getSubmissionsByAssignment(assignmentId);
                // Implement grading logic
            } else {
                JOptionPane.showMessageDialog(teacherDashboardView, 
                    "Please select an assignment first", 
                    "No Assignment Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class ViewSubmissionsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int assignmentId = teacherDashboardView.getSelectedAssignmentId();
            if (assignmentId != -1) {
                // Open submissions view
                // List<Submission> submissions = submissionDAO.getSubmissionsByAssignment(assignmentId);
                // Implement submissions viewing logic
            } else {
                JOptionPane.showMessageDialog(teacherDashboardView, 
                    "Please select an assignment first", 
                    "No Assignment Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    class SubmitAssignmentListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int assignmentId = studentDashboardView.getSelectedAssignmentId();
            if (assignmentId != -1) {
                // Open file chooser and submission dialog
                // Submission submission = new Submission();
                // submission.setAssignmentId(assignmentId);
                // submission.setStudentId(studentId);
                // submission.setFilePath(filePath);
                
                // boolean success = submissionDAO.submitAssignment(submission);
                // if (success) {
                //     JOptionPane.showMessageDialog(studentDashboardView, 
                //         "Assignment submitted successfully", 
                //         "Success", 
                //         JOptionPane.INFORMATION_MESSAGE);
                //     loadAssignmentsForStudent(studentId);
                // }
            } else {
                JOptionPane.showMessageDialog(studentDashboardView, 
                    "Please select an assignment first", 
                    "No Assignment Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
    
    // Methods to load assignments for different views
    public void loadAssignmentsForTeacher(int teacherId) {
        List<Assignment> assignments = assignmentDAO.getAssignmentsByTeacher(teacherId);
        teacherDashboardView.displayAssignments(assignments);
    }
    
    public void loadAssignmentsForCourse(int courseId) {
        List<Assignment> assignments = assignmentDAO.getAssignmentsByCourse(courseId);
        // Update appropriate view
    }
    
    public void loadAssignmentsForStudent(int studentId) {
        // Get courses the student is enrolled in
        // Get assignments for those courses
        // Update student dashboard view
    }
    
    // Other assignment management methods
    public boolean createAssignment(Assignment assignment) {
        return assignmentDAO.createAssignment(assignment);
    }
    
    public boolean updateAssignment(Assignment assignment) {
        return assignmentDAO.updateAssignment(assignment);
    }
    
    public boolean deleteAssignment(int assignmentId) {
        return assignmentDAO.deleteAssignment(assignmentId);
    }
    
    public boolean submitAssignment(Submission submission) {
        return submissionDAO.submitAssignment(submission);
    }
    
    public boolean gradeSubmission(int submissionId, int grade, String feedback) {
        return submissionDAO.gradeSubmission(submissionId, grade, feedback);
    }
}