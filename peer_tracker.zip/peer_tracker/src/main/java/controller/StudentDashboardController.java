package controller;

import dao.AssignmentDAO;
import dao.CourseDAO;
import dao.EnrollmentDAO;
import dao.MessageDAO;
import dao.NotificationDAO;
import dao.StudyGroupDAO;
import dao.SubmissionDAO;
import dao.UserDAO;
import model.Assignment;
import model.Course;
import model.Message;
import model.Notification;
import model.StudyGroup;
import model.User;
import view.StudentDashboardView;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StudentDashboardController {
    private StudentDashboardView studentDashboardView;
    private AssignmentDAO assignmentDAO;
    private SubmissionDAO submissionDAO;
    private CourseDAO courseDAO;
    private EnrollmentDAO enrollmentDAO;
    private StudyGroupDAO studyGroupDAO;
    private UserDAO userDAO;
    private MessageDAO messageDAO;
    private NotificationDAO notificationDAO;
    private int currentStudentId; // The ID of the logged-in student

    public StudentDashboardController(StudentDashboardView studentDashboardView, AssignmentDAO assignmentDAO,
                                      SubmissionDAO submissionDAO, CourseDAO courseDAO, EnrollmentDAO enrollmentDAO,
                                      StudyGroupDAO studyGroupDAO, UserDAO userDAO, MessageDAO messageDAO,
                                      NotificationDAO notificationDAO, int currentStudentId) {
        this.studentDashboardView = studentDashboardView;
        this.assignmentDAO = assignmentDAO;
        this.submissionDAO = submissionDAO;
        this.courseDAO = courseDAO;
        this.enrollmentDAO = enrollmentDAO;
        this.studyGroupDAO = studyGroupDAO;
        this.userDAO = userDAO;
        this.messageDAO = messageDAO;
        this.notificationDAO = notificationDAO;
        this.currentStudentId = currentStudentId;

        // Load initial data
        loadCoursesForStudent(currentStudentId);
        loadAssignmentsForStudent(currentStudentId);
        loadMyStudyGroups(currentStudentId);
        loadMyMentors(currentStudentId);
        loadAllAvailableMentors();

        // Register listeners
        registerListeners();
    }

    private void registerListeners() {
        studentDashboardView.addSubmitAssignmentListener(new SubmitAssignmentListener());
        studentDashboardView.addViewPeerReviewsListener(new ViewPeerReviewsListener());

        // Study Group Listeners
        studentDashboardView.addCreateGroupListener(new CreateGroupListener());
        studentDashboardView.addEditGroupListener(new EditGroupListener());
        studentDashboardView.addDeleteGroupListener(new DeleteGroupListener());

        // Mentor Listeners
        studentDashboardView.addAddMentorListener(new AddMentorListener());
    }

    private void loadCoursesForStudent(int studentId) {
        // This would typically involve getting courses the student is enrolled in
        // For now, a placeholder
        List<Course> courses = courseDAO.getAllCourses(); // Or getCoursesByStudent(studentId)
        studentDashboardView.displayCourses(courses);
    }

    private void loadAssignmentsForStudent(int studentId) {
        // This would involve getting assignments for courses the student is enrolled in
        // For now, a placeholder
        List<Assignment> assignments = assignmentDAO.getAssignmentsByTeacher(1); // Placeholder
        studentDashboardView.displayAssignments(assignments);
    }

    private void loadMyStudyGroups(int studentId) {
        List<StudyGroup> myGroups = studyGroupDAO.getGroupsForUser(studentId);
        studentDashboardView.populateMyStudyGroups(myGroups);
    }

    private void loadMyMentors(int studentId) {
        User student = userDAO.getUserById(studentId);
        List<User> myMentors = new ArrayList<>();
        if (student != null && student.getParentId() != null) { // Assuming parentId is used for mentor_id for simplicity
            User mentor = userDAO.getUserById(student.getParentId()); // This is a simplification, ideally a dedicated mentor_id field
            if (mentor != null && mentor.getRole().equals("Mentor")) {
                myMentors.add(mentor);
            }
        }
        studentDashboardView.populateMyMentors(myMentors);
    }

    private void loadAllAvailableMentors() {
        List<User> allMentors = userDAO.getUsersByRole("Mentor");
        studentDashboardView.populateAllMentors(allMentors);
    }

    // Assignment Listeners (existing)
    class SubmitAssignmentListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int assignmentId = studentDashboardView.getSelectedAssignmentId();
            if (assignmentId != -1) {
                JOptionPane.showMessageDialog(studentDashboardView,
                    "Submit Assignment for ID: " + assignmentId + " (Logic to be implemented)",
                    "Submit Assignment",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(studentDashboardView,
                    "Please select an assignment first",
                    "No Assignment Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    class ViewPeerReviewsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            int assignmentId = studentDashboardView.getSelectedAssignmentId();
            if (assignmentId != -1) {
                JOptionPane.showMessageDialog(studentDashboardView,
                    "View Peer Reviews for Assignment ID: " + assignmentId + " (Logic to be implemented)",
                    "View Peer Reviews",
                    JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(studentDashboardView,
                    "Please select an assignment first",
                    "No Assignment Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    // Study Group Listeners (new)
    class CreateGroupListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String name = JOptionPane.showInputDialog(studentDashboardView, "Enter group name:");
            if (name == null || name.trim().isEmpty()) return;

            String description = JOptionPane.showInputDialog(studentDashboardView, "Enter group description:");
            if (description == null || description.trim().isEmpty()) return;

            String meetingSchedule = JOptionPane.showInputDialog(studentDashboardView, "Enter meeting schedule (e.g., Mon 3 PM, Online):");
            if (meetingSchedule == null || meetingSchedule.trim().isEmpty()) return;

            String memberIdsStr = JOptionPane.showInputDialog(studentDashboardView, "Enter member IDs (comma-separated, include yourself if desired):");
            List<Integer> memberIds = new ArrayList<>();
            if (memberIdsStr != null && !memberIdsStr.trim().isEmpty()) {
                try {
                    memberIds = Arrays.stream(memberIdsStr.split(","))
                                      .map(String::trim)
                                      .map(Integer::parseInt)
                                      .collect(Collectors.toList());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(studentDashboardView, "Invalid member IDs. Please enter numbers separated by commas.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
            // Ensure the creator is part of the group
            if (!memberIds.contains(currentStudentId)) {
                memberIds.add(currentStudentId);
            }

            // Optional: Link to a course
            String courseIdStr = JOptionPane.showInputDialog(studentDashboardView, "Enter Course ID (optional, leave blank if none):");
            Integer courseId = null;
            if (courseIdStr != null && !courseIdStr.trim().isEmpty()) {
                try {
                    courseId = Integer.parseInt(courseIdStr.trim());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(studentDashboardView, "Invalid Course ID. Please enter a number.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            boolean success = studyGroupDAO.createStudyGroup(name, description, currentStudentId, memberIds, meetingSchedule, courseId);
            if (success) {
                JOptionPane.showMessageDialog(studentDashboardView, "Study group created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadMyStudyGroups(currentStudentId); // Refresh list
                // Notify members
                User creator = userDAO.getUserById(currentStudentId);
                for (int memberId : memberIds) {
                    if (memberId != currentStudentId) { // Don't notify self
                        Notification notification = new Notification();
                        notification.setUserId(memberId);
                        notification.setType(Notification.Type.STUDY_GROUP);
                        notification.setMessage("You've been added to study group '" + name + "' by " + creator.getName());
                        notification.setRelatedEntityType("StudyGroup");
                        // Assuming studyGroupDAO.createStudyGroup returns the created group with ID
                        // For now, we'll need to fetch it or modify createStudyGroup to return ID
                        // notification.setRelatedEntityId(newGroupId);
                        notificationDAO.saveNotification(notification);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(studentDashboardView, "Failed to create study group.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    class EditGroupListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            StudyGroup selectedGroup = studentDashboardView.getSelectedStudyGroup();
            if (selectedGroup == null) {
                JOptionPane.showMessageDialog(studentDashboardView, "Please select a study group to edit.", "No Group Selected", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Only allow creator to edit
            if (selectedGroup.getCreatorId() != currentStudentId) {
                JOptionPane.showMessageDialog(studentDashboardView, "You can only edit groups you created.", "Permission Denied", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String newName = JOptionPane.showInputDialog(studentDashboardView, "Edit group name:", selectedGroup.getName());
            if (newName == null || newName.trim().isEmpty()) return;

            String newDescription = JOptionPane.showInputDialog(studentDashboardView, "Edit group description:", selectedGroup.getDescription());
            if (newDescription == null || newDescription.trim().isEmpty()) return;

            String newMeetingSchedule = JOptionPane.showInputDialog(studentDashboardView, "Edit meeting schedule:", selectedGroup.getMeetingSchedule());
            if (newMeetingSchedule == null || newMeetingSchedule.trim().isEmpty()) return;

            // For members, it's more complex. For simplicity, let's just update basic info.
            // A full implementation would involve a separate dialog for member management.
            selectedGroup.setName(newName.trim());
            selectedGroup.setDescription(newDescription.trim());
            selectedGroup.setMeetingSchedule(newMeetingSchedule.trim());

            boolean success = studyGroupDAO.updateStudyGroup(selectedGroup);
            if (success) {
                JOptionPane.showMessageDialog(studentDashboardView, "Study group updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadMyStudyGroups(currentStudentId); // Refresh list
            } else {
                JOptionPane.showMessageDialog(studentDashboardView, "Failed to update study group.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    class DeleteGroupListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            StudyGroup selectedGroup = studentDashboardView.getSelectedStudyGroup();
            if (selectedGroup == null) {
                JOptionPane.showMessageDialog(studentDashboardView, "Please select a study group to delete.", "No Group Selected", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Only allow creator to delete
            if (selectedGroup.getCreatorId() != currentStudentId) {
                JOptionPane.showMessageDialog(studentDashboardView, "You can only delete groups you created.", "Permission Denied", JOptionPane.ERROR_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(studentDashboardView,
                "Are you sure you want to delete the group '" + selectedGroup.getName() + "'?", "Confirm Deletion", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                boolean success = studyGroupDAO.deleteStudyGroup(selectedGroup.getGroupId());
                if (success) {
                    JOptionPane.showMessageDialog(studentDashboardView, "Study group deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadMyStudyGroups(currentStudentId); // Refresh list
                } else {
                    JOptionPane.showMessageDialog(studentDashboardView, "Failed to delete study group.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    // Mentor Listeners (new)
    class AddMentorListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            User selectedMentor = studentDashboardView.getSelectedAvailableMentor();
            if (selectedMentor == null) {
                JOptionPane.showMessageDialog(studentDashboardView, "Please select a mentor from the 'Available Mentors' list.", "No Mentor Selected", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(studentDashboardView,
                "Do you want to add " + selectedMentor.getName() + " as your mentor?", "Confirm Mentor", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                User student = userDAO.getUserById(currentStudentId);
                if (student != null) {
                    // Assuming 'parentId' is repurposed for 'mentor_id' for simplicity, or add a new field to User model
                    // For a robust solution, a separate 'mentorships' table would be better.
                    // Here, we'll update the student's parentId to be the mentor's ID.
                    // This is a temporary workaround for the given schema.
                    student.setParentId(selectedMentor.getUserId()); // Using parentId as mentor_id
                    boolean success = userDAO.updateUser(student);

                    if (success) {
                        JOptionPane.showMessageDialog(studentDashboardView, selectedMentor.getName() + " added as your mentor!", "Success", JOptionPane.INFORMATION_MESSAGE);
                        loadMyMentors(currentStudentId); // Refresh my mentors list

                        // Send message/notification to the mentor
                        String messageContent = "Student " + student.getName() + " (" + student.getEmail() + ") has added you as their mentor. You can now schedule sessions with them.";
                        Message message = new Message();
                        message.setSenderId(currentStudentId);
                        message.setReceiverId(selectedMentor.getUserId());
                        message.setContent(messageContent);
                        messageDAO.sendMessage(message);

                        Notification notification = new Notification();
                        notification.setUserId(selectedMentor.getUserId());
                        notification.setType(Notification.Type.PEER_MESSAGE); // Or a new type like MENTOR_REQUEST
                        notification.setMessage("New Mentee: " + student.getName() + " has added you as their mentor.");
                        notification.setRelatedEntityType("User");
                        notification.setRelatedEntityId(currentStudentId);
                        notificationDAO.saveNotification(notification);

                        JOptionPane.showMessageDialog(studentDashboardView, "A notification has been sent to " + selectedMentor.getName() + ".", "Notification Sent", JOptionPane.INFORMATION_MESSAGE);

                    } else {
                        JOptionPane.showMessageDialog(studentDashboardView, "Failed to add mentor.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }
    }
}
