package controller;

import dao.MatchingDAO;
import dao.NotificationDAO;
import dao.UserDAO;
import model.MatchCriteria;
import model.Notification;
import model.User;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import javax.swing.JOptionPane;
import java.util.List;

public class PeerMatchingController {
    private MatchingDAO matchingDAO;
    private UserDAO userDAO;
    private NotificationDAO notificationDAO;
    private ScheduledExecutorService scheduler;
    
    public PeerMatchingController(MatchingDAO matchingDAO, UserDAO userDAO, 
                                NotificationDAO notificationDAO) {
        this.matchingDAO = matchingDAO;
        this.userDAO = userDAO;
        this.notificationDAO = notificationDAO;
    }
    
    public void startDailyMatching() {
        if (scheduler != null && !scheduler.isShutdown()) {
            scheduler.shutdown();
        }
        
        scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(this::runDailyMatching, 0, 1, TimeUnit.DAYS);
    }
    
    private void runDailyMatching() {
        List<User> activeStudents = userDAO.getActiveStudents();
        for (User student : activeStudents) {
            MatchCriteria criteria = new MatchCriteria();
            criteria.setUserId(student.getUserId());
            // Set other criteria from student's profile
            
            List<User> matches = matchingDAO.findMatchingPeers(criteria);
            if (!matches.isEmpty()) {
                sendMatchNotification(student, matches);
            }
        }
    }
    
    private void sendMatchNotification(User student, List<User> matches) {
        Notification notification = new Notification();
        notification.setUserId(student.getUserId());
        notification.setType(Notification.Type.STUDY_GROUP);
        notification.setMessage(String.format(
            "We found %d potential study partners for you! Click to view suggestions.", 
            matches.size()
        ));
        notification.setRelatedEntityType("PeerMatching");
        notificationDAO.saveNotification(notification);
    }
    
    public void stop() {
        if (scheduler != null) {
            scheduler.shutdown();
        }
    }
    
    public List<User> findMatchesForUser(int userId) {
        User user = userDAO.getUserById(userId);
        MatchCriteria criteria = new MatchCriteria();
        criteria.setUserId(userId);
        // Populate criteria from user's profile
        return matchingDAO.findMatchingPeers(criteria);
    }
}