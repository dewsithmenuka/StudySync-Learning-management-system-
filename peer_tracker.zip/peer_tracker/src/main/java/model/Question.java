package model;

import java.util.List;

public class Question {
    private int questionId;
    private int quizId;
    private String questionText;
    private QuestionType type; // MULTIPLE_CHOICE, TRUE_FALSE, SHORT_ANSWER
    private List<String> options;
    private String correctAnswer;
    private int points;
    private String explanation;
    
    public enum QuestionType {
        MULTIPLE_CHOICE, TRUE_FALSE, SHORT_ANSWER
    }
    
    // Constructors
    public Question() {}
    
    public Question(int questionId, int quizId, String questionText, QuestionType type, 
                   List<String> options, String correctAnswer, int points, String explanation) {
        this.questionId = questionId;
        this.quizId = quizId;
        this.questionText = questionText;
        this.type = type;
        this.options = options;
        this.correctAnswer = correctAnswer;
        this.points = points;
        this.explanation = explanation;
    }
    
    // Getters and Setters
    public int getQuestionId() { return questionId; }
    public void setQuestionId(int questionId) { this.questionId = questionId; }
    
    public int getQuizId() { return quizId; }
    public void setQuizId(int quizId) { this.quizId = quizId; }
    
    public String getQuestionText() { return questionText; }
    public void setQuestionText(String questionText) { this.questionText = questionText; }
    
    public QuestionType getType() { return type; }
    public void setType(QuestionType type) { this.type = type; }
    
    public List<String> getOptions() { return options; }
    public void setOptions(List<String> options) { this.options = options; }
    
    public String getCorrectAnswer() { return correctAnswer; }
    public void setCorrectAnswer(String correctAnswer) { this.correctAnswer = correctAnswer; }
    
    public int getPoints() { return points; }
    public void setPoints(int points) { this.points = points; }
    
    public String getExplanation() { return explanation; }
    public void setExplanation(String explanation) { this.explanation = explanation; }
    
    public boolean isCorrect(String answer) {
        return correctAnswer.equalsIgnoreCase(answer);
    }
}