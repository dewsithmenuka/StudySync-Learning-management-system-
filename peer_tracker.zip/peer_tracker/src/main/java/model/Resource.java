package model;

import java.time.LocalDateTime;

public class Resource {
    private int resourceId;
    private int mentorId;
    private String title;
    private String description;
    private String filePath;
    private LocalDateTime uploadDate;

    public Resource() {}

    public Resource(int resourceId, int mentorId, String title, String description, String filePath, LocalDateTime uploadDate) {
        this.resourceId = resourceId;
        this.mentorId = mentorId;
        this.title = title;
        this.description = description;
        this.filePath = filePath;
        this.uploadDate = uploadDate;
    }

    // Getters and Setters
    public int getResourceId() { return resourceId; }
    public void setResourceId(int resourceId) { this.resourceId = resourceId; }

    public int getMentorId() { return mentorId; }
    public void setMentorId(int mentorId) { this.mentorId = mentorId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public LocalDateTime getUploadDate() { return uploadDate; }
    public void setUploadDate(LocalDateTime uploadDate) { this.uploadDate = uploadDate; }
}
