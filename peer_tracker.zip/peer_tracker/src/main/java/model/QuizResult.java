package model;

import java.time.LocalDateTime;

public class QuizResult {
    private int resultId;
    private int quizId;
    private int userId;
    private int score;
    private int totalPoints;
    private LocalDateTime completedAt;

    // Constructors
    public QuizResult() {}
    
    public QuizResult(int resultId, int quizId, int userId, int score, 
                     int totalPoints, LocalDateTime completedAt) {
        this.resultId = resultId;
        this.quizId = quizId;
        this.userId = userId;
        this.score = score;
        this.totalPoints = totalPoints;
        this.completedAt = completedAt;
    }

    // Getters and Setters
    public int getResultId() { return resultId; }
    public void setResultId(int resultId) { this.resultId = resultId; }
    
    public int getQuizId() { return quizId; }
    public void setQuizId(int quizId) { this.quizId = quizId; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public int getScore() { return score; }
    public void setScore(int score) { this.score = score; }
    
    public int getTotalPoints() { return totalPoints; }
    public void setTotalPoints(int totalPoints) { this.totalPoints = totalPoints; }
    
    public LocalDateTime getCompletedAt() { return completedAt; }
    public void setCompletedAt(LocalDateTime completedAt) { this.completedAt = completedAt; }
}