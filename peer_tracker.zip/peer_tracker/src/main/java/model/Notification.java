package model;

import java.time.LocalDateTime;

public class Notification {
    public enum Type {
        ASSIGNMENT_DUE, 
        PEER_MESSAGE, 
        STUDY_GROUP, 
        FEEDBACK_RECEIVED,
        SYSTEM_ANNOUNCEMENT
    }
    
    private int notificationId;
    private int userId;
    private Type type;
    private String message;
    private String relatedEntityType; // "Assignment", "Message", etc.
    private int relatedEntityId;
    private LocalDateTime createdAt;
    private boolean isRead;
    
    public Notification() {}
    
    // Getters and Setters
    public int getNotificationId() { return notificationId; }
    public void setNotificationId(int notificationId) { this.notificationId = notificationId; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public Type getType() { return type; }
    public void setType(Type type) { this.type = type; }
    
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    
    public String getRelatedEntityType() { return relatedEntityType; }
    public void setRelatedEntityType(String relatedEntityType) { this.relatedEntityType = relatedEntityType; }
    
    public int getRelatedEntityId() { return relatedEntityId; }
    public void setRelatedEntityId(int relatedEntityId) { this.relatedEntityId = relatedEntityId; }
    
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    
    public boolean isRead() { return isRead; }
    public void setRead(boolean read) { isRead = read; }
}