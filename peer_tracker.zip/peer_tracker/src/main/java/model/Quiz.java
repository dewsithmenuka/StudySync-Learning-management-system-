package model;

import java.time.LocalDateTime;
import java.util.List;

public class Quiz {
    private int quizId;
    private int courseId;
    private String title;
    private String description;
    private List<Question> questions;
    private LocalDateTime availableFrom;
    private LocalDateTime availableTo;
    private int timeLimit; // in minutes
    private boolean isPublished;
    
    // Constructors
    public Quiz() {}
    
    public Quiz(int quizId, int courseId, String title, String description, 
               List<Question> questions, LocalDateTime availableFrom, 
               LocalDateTime availableTo, int timeLimit, boolean isPublished) {
        this.quizId = quizId;
        this.courseId = courseId;
        this.title = title;
        this.description = description;
        this.questions = questions;
        this.availableFrom = availableFrom;
        this.availableTo = availableTo;
        this.timeLimit = timeLimit;
        this.isPublished = isPublished;
    }
    
    // Getters and Setters
    public int getQuizId() { return quizId; }
    public void setQuizId(int quizId) { this.quizId = quizId; }
    
    public int getCourseId() { return courseId; }
    public void setCourseId(int courseId) { this.courseId = courseId; }
    
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public List<Question> getQuestions() { return questions; }
    public void setQuestions(List<Question> questions) { this.questions = questions; }
    
    public LocalDateTime getAvailableFrom() { return availableFrom; }
    public void setAvailableFrom(LocalDateTime availableFrom) { this.availableFrom = availableFrom; }
    
    public LocalDateTime getAvailableTo() { return availableTo; }
    public void setAvailableTo(LocalDateTime availableTo) { this.availableTo = availableTo; }
    
    public int getTimeLimit() { return timeLimit; }
    public void setTimeLimit(int timeLimit) { this.timeLimit = timeLimit; }
    
    public boolean isPublished() { return isPublished; }
    public void setPublished(boolean published) { isPublished = published; }
    
    public int getTotalPoints() {
        return questions.stream().mapToInt(Question::getPoints).sum();
    }
}