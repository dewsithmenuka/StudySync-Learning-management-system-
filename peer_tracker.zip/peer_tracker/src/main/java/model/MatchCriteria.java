package model;

import java.util.List;

public class MatchCriteria {
    private int userId;
    private String skillLevel; // novice, intermediate, advanced
    private String learningStyle; // visual, auditory, kinesthetic
    private List<String> availableDays;
    private List<String> preferredTimes;
    private List<Integer> courseInterests;
    
    public MatchCriteria() {}
    
    public MatchCriteria(int userId, String skillLevel, String learningStyle, 
                        List<String> availableDays, List<String> preferredTimes, 
                        List<Integer> courseInterests) {
        this.userId = userId;
        this.skillLevel = skillLevel;
        this.learningStyle = learningStyle;
        this.availableDays = availableDays;
        this.preferredTimes = preferredTimes;
        this.courseInterests = courseInterests;
    }
    
    // Getters and Setters
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public String getSkillLevel() { return skillLevel; }
    public void setSkillLevel(String skillLevel) { this.skillLevel = skillLevel; }
    
    public String getLearningStyle() { return learningStyle; }
    public void setLearningStyle(String learningStyle) { this.learningStyle = learningStyle; }
    
    public List<String> getAvailableDays() { return availableDays; }
    public void setAvailableDays(List<String> availableDays) { this.availableDays = availableDays; }
    
    public List<String> getPreferredTimes() { return preferredTimes; }
    public void setPreferredTimes(List<String> preferredTimes) { this.preferredTimes = preferredTimes; }
    
    public List<Integer> getCourseInterests() { return courseInterests; }
    public void setCourseInterests(List<Integer> courseInterests) { this.courseInterests = courseInterests; }
    
    public int getSkillLevelRank() {
        switch(skillLevel.toLowerCase()) {
            case "novice": return 1;
            case "intermediate": return 2;
            case "advanced": return 3;
            default: return 0;
        }
    }
}