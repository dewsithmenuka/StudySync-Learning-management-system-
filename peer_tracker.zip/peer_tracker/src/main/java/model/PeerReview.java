package model;

import java.time.LocalDateTime;

public class PeerReview {
    private int reviewId;
    private int submissionId;
    private int reviewerId;
    private int rating;
    private String comments;
    private LocalDateTime reviewedAt;

    // Constructors, Getters and Setters
    public PeerReview() {}

    public PeerReview(int reviewId, int submissionId, int reviewerId, 
                     int rating, String comments, LocalDateTime reviewedAt) {
        this.reviewId = reviewId;
        this.submissionId = submissionId;
        this.reviewerId = reviewerId;
        this.rating = rating;
        this.comments = comments;
        this.reviewedAt = reviewedAt;
    }

    public int getReviewId() { return reviewId; }
    public void setReviewId(int reviewId) { this.reviewId = reviewId; }
    
    public int getSubmissionId() { return submissionId; }
    public void setSubmissionId(int submissionId) { this.submissionId = submissionId; }
    
    public int getReviewerId() { return reviewerId; }
    public void setReviewerId(int reviewerId) { this.reviewerId = reviewerId; }
    
    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }
    
    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }
    
    public LocalDateTime getReviewedAt() { return reviewedAt; }
    public void setReviewedAt(LocalDateTime reviewedAt) { this.reviewedAt = reviewedAt; }
}