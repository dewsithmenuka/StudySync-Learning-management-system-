package model;

public class StudentProgress {
    private int studentId;
    private String studentName;
    private int courseId;
    private String courseName;
    private int completedAssignments;
    private int totalAssignments;
    private double averageScore;
    private String lastActiveDate;
    private int progressPercentage;

    public StudentProgress(int studentId, String studentName, int courseId, String courseName,
                         int completedAssignments, int totalAssignments, double averageScore,
                         String lastActiveDate, int progressPercentage) {
        this.studentId = studentId;
        this.studentName = studentName;
        this.courseId = courseId;
        this.courseName = courseName;
        this.completedAssignments = completedAssignments;
        this.totalAssignments = totalAssignments;
        this.averageScore = averageScore;
        this.lastActiveDate = lastActiveDate;
        this.progressPercentage = progressPercentage;
    }

    // Getters
    public int getStudentId() { return studentId; }
    public String getStudentName() { return studentName; }
    public int getCourseId() { return courseId; }
    public String getCourseName() { return courseName; }
    public int getCompletedAssignments() { return completedAssignments; }
    public int getTotalAssignments() { return totalAssignments; }
    public double getAverageScore() { return averageScore; }
    public String getLastActiveDate() { return lastActiveDate; }
    public int getProgressPercentage() { return progressPercentage; }
}
