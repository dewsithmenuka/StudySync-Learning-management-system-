import controller.*;
import dao.*;
import view.*;
import util.DatabaseConnection;

public class MainApp {
    public static void main(String[] args) {
        // Initialize database connection
        DatabaseConnection.getConnection();
        
        // Create DAOs
        UserDAO userDAO = new UserDAO();
        
        // Create views
        LoginView loginView = new LoginView();
        
        // Create controllers
        LoginController loginController = new LoginController(loginView, userDAO);
        
        // Show login view
        loginView.setVisible(true);
        
        // Add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            DatabaseConnection.closeConnection();
        }));
    }
}