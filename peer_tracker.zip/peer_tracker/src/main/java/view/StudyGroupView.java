// view/StudyGroupView.java
package view;

import controller.StudyGroupController;
import model.StudyGroup;
import model.User;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class StudyGroupView extends JFrame {
    private StudyGroupController controller;
    private int userId;

    private JList<StudyGroup> groupList;
    private JButton createGroupButton;
    private JButton viewGroupButton;

    public StudyGroupView(StudyGroupController controller, int userId) {
        this.controller = controller;
        this.userId = userId;

        setTitle("Study Groups");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        initUI();
        loadGroups();
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Group list
        groupList = new JList<>();
        groupList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(groupList);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        createGroupButton = new JButton("Create New Group");
        viewGroupButton = new JButton("View Selected Group");

        createGroupButton.addActionListener(new CreateGroupListener());
        viewGroupButton.addActionListener(new ViewGroupListener());

        buttonPanel.add(createGroupButton);
        buttonPanel.add(viewGroupButton);

        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void loadGroups() {
        List<StudyGroup> groups = controller.getGroupsForUser (userId);
        groupList.setListData(groups.toArray(new StudyGroup[0]));
    }

    class CreateGroupListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // Open create group dialog
            new CreateGroupDialog(StudyGroupView.this, controller, userId).setVisible(true);
        }
    }

    class ViewGroupListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            StudyGroup selected = groupList.getSelectedValue();
            if (selected != null) {
                // Open group detail view
                new GroupDetailView(selected).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(StudyGroupView.this,
                    "Please select a group first",
                    "No Group Selected",
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}
