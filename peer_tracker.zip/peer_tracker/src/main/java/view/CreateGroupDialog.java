// view/CreateGroupDialog.java
package view;

import controller.StudyGroupController; // Import the controller
import javax.swing.*;
import java.awt.*;

public class CreateGroupDialog extends JDialog {
    private StudyGroupController controller;
    private int userId;

    public CreateGroupDialog(JFrame parent, StudyGroupController controller, int userId) {
        super(parent, "Create New Study Group", true); // Changed title
        this.controller = controller;
        this.userId = userId;

        setSize(400, 300);
        setLocationRelativeTo(parent);

        JPanel panel = new JPanel(new GridLayout(4, 2, 5, 5));
        panel.add(new JLabel("Group Name:"));
        JTextField groupNameField = new JTextField();
        panel.add(groupNameField);
        panel.add(new JLabel("Description:"));
        JTextField descriptionField = new JTextField();
        panel.add(descriptionField);
        panel.add(new JLabel("Members (comma-separated IDs):")); // Changed label
        JTextField membersField = new JTextField(); // Changed to JTextField for IDs
        panel.add(membersField);
        panel.add(new JLabel("Meeting Schedule:"));
        JTextField scheduleField = new JTextField();
        panel.add(scheduleField);

        JButton createButton = new JButton("Create");
        createButton.addActionListener(e -> {
            String name = groupNameField.getText();
            String description = descriptionField.getText();
            String membersText = membersField.getText();
            String schedule = scheduleField.getText();

            // Basic validation
            if (name.isEmpty() || description.isEmpty() || membersText.isEmpty() || schedule.isEmpty()) {
                JOptionPane.showMessageDialog(this, "All fields are required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Parse member IDs
            java.util.List<Integer> memberIds = new java.util.ArrayList<>();
            try {
                for (String id : membersText.split(",")) {
                    memberIds.add(Integer.parseInt(id.trim()));
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid member IDs. Please enter comma-separated numbers.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Add creator to members if not already present
            if (!memberIds.contains(userId)) {
                memberIds.add(userId);
            }

            // Call controller to create group
            boolean success = controller.createStudyGroup(name, description, userId, memberIds, schedule, null); // courseId is null for now
            if (success) {
                JOptionPane.showMessageDialog(this, "Study group created successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to create study group.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        panel.add(createButton);

        add(panel);
    }
}
