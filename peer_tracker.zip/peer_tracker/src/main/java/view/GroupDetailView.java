// view/GroupDetailView.java
package view;

import model.StudyGroup; // Import StudyGroup
import javax.swing.*;
import java.awt.*;

public class GroupDetailView extends JFrame {
    private StudyGroup studyGroup; // Add a field to hold the StudyGroup object

    public GroupDetailView(StudyGroup studyGroup) { // Modify constructor to accept StudyGroup
        this.studyGroup = studyGroup; // Initialize the studyGroup field
        setTitle("Group Details: " + studyGroup.getName()); // Use group name in title
        setSize(600, 400);
        setLocationRelativeTo(null);

        JTabbedPane tabbedPane = new JTabbedPane();

        // Members Tab
        JPanel membersPanel = new JPanel(new BorderLayout());
        JTextArea membersArea = new JTextArea("Creator: " + studyGroup.getCreatorId() + "\n");
        // You'll need to fetch actual member names from the database using UserDAO
        // For now, just display member IDs if available
        if (studyGroup.getMemberIds() != null) {
            membersArea.append("Members: " + studyGroup.getMemberIds().toString());
        }
        membersArea.setEditable(false);
        membersPanel.add(new JScrollPane(membersArea), BorderLayout.CENTER);
        tabbedPane.addTab("Members", membersPanel);

        // Schedule Tab
        JPanel schedulePanel = new JPanel(new BorderLayout());
        JTextArea scheduleArea = new JTextArea("Meeting Schedule: " + studyGroup.getMeetingSchedule());
        scheduleArea.setEditable(false);
        schedulePanel.add(new JScrollPane(scheduleArea), BorderLayout.CENTER);
        tabbedPane.addTab("Schedule", schedulePanel);

        // Resources Tab (placeholder)
        JPanel resourcesPanel = new JPanel();
        resourcesPanel.add(new JLabel("Resources for " + studyGroup.getName() + " (To be implemented)"));
        tabbedPane.addTab("Resources", resourcesPanel);

        add(tabbedPane);
    }
}
