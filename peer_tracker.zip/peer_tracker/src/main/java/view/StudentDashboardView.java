package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import model.Course;
import model.Assignment;
import model.StudyGroup;
import model.User;
import javax.swing.table.DefaultTableModel;

public class StudentDashboardView extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable coursesTable;
    private JTable assignmentsTable;
    private JButton submitAssignmentButton, joinGroupButton;
    private JButton requestMentorButton, viewPeerReviewsButton;
    private JComboBox<StudyGroup> availableGroupsCombo;
    private JComboBox<User> availableMentorsCombo;
    private JList<StudyGroup> groupsList; // Added to make it accessible
    private JList<User> mentorsList; // Added to make it accessible

    // New UI elements for Study Group Management
    private JButton createGroupButton;
    private JButton editGroupButton;
    private JButton deleteGroupButton;

    // New UI elements for Mentor Management
    private JButton addMentorButton; // Button to add selected mentor
    private JList<User> allMentorsList; // List of all available mentors

    public StudentDashboardView() {
        setTitle("Student Dashboard - Peer-to-Peer Learning Tracker");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        // Main panel with gradient
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                Color color1 = new Color(147, 112, 219); // MediumPurple
                Color color2 = new Color(216, 191, 216); // Thistle
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        // Header panel
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setOpaque(false);
        JLabel titleLabel = new JLabel("Student Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);

        // Tabbed pane for different functions
        tabbedPane = new JTabbedPane();
        tabbedPane.setOpaque(false);

        // My Courses Tab
        JPanel coursesPanel = createCoursesPanel();
        tabbedPane.addTab("My Courses", coursesPanel);

        // Assignments Tab
        JPanel assignmentsPanel = createAssignmentsPanel();
        tabbedPane.addTab("Assignments", assignmentsPanel);

        // Peer Groups Tab
        JPanel groupsPanel = createGroupsPanel();
        tabbedPane.addTab("Peer Groups", groupsPanel);

        // Mentors Tab
        JPanel mentorsTab = createMentorsTab();
        tabbedPane.addTab("Mentors", mentorsTab);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        add(mainPanel);
    }

    private JPanel createCoursesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        // Courses table
        String[] columnNames = {"Course ID", "Title", "Description", "Progress"};
        coursesTable = new JTable(new DefaultTableModel(columnNames, 0));
        JScrollPane scrollPane = new JScrollPane(coursesTable);

        panel.add(scrollPane, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createAssignmentsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        String[] columnNames = {"Assignment ID", "Course", "Title", "Due Date", "Status"};
        Object[][] data = {};
        assignmentsTable = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(assignmentsTable);

        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);

        submitAssignmentButton = new JButton("Submit Assignment");
        submitAssignmentButton.setBackground(new Color(60, 179, 113));
        submitAssignmentButton.setForeground(Color.WHITE);

        viewPeerReviewsButton = new JButton("View Peer Reviews");
        viewPeerReviewsButton.setBackground(new Color(123, 104, 238));
        viewPeerReviewsButton.setForeground(Color.WHITE);

        buttonPanel.add(submitAssignmentButton);
        buttonPanel.add(viewPeerReviewsButton);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createGroupsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Main content panel with card layout
        JPanel contentPanel = new JPanel(new CardLayout());
        contentPanel.setOpaque(false);

        // Peer Groups card
        JPanel peerGroupsCard = new JPanel(new BorderLayout());
        peerGroupsCard.setOpaque(false);

        // Registered Study Groups Section
        JPanel studyGroupsPanel = new JPanel(new BorderLayout());
        studyGroupsPanel.setBorder(BorderFactory.createTitledBorder("My Study Groups"));
        studyGroupsPanel.setOpaque(false);

        DefaultListModel<StudyGroup> groupsModel = new DefaultListModel<>();
        groupsList = new JList<>(groupsModel);
        groupsList.setCellRenderer(new StudyGroupListCellRenderer());
        JScrollPane groupsScrollPane = new JScrollPane(groupsList);

        studyGroupsPanel.add(groupsScrollPane, BorderLayout.CENTER);

        // Study Group Management Buttons
        JPanel groupButtonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        groupButtonsPanel.setOpaque(false);

        createGroupButton = new JButton("Create New Group");
        createGroupButton.setBackground(new Color(34, 139, 34)); // ForestGreen
        createGroupButton.setForeground(Color.WHITE);

        editGroupButton = new JButton("Edit Selected Group");
        editGroupButton.setBackground(new Color(255, 140, 0)); // DarkOrange
        editGroupButton.setForeground(Color.WHITE);

        deleteGroupButton = new JButton("Delete Selected Group");
        deleteGroupButton.setBackground(new Color(220, 20, 60)); // Crimson
        deleteGroupButton.setForeground(Color.WHITE);

        groupButtonsPanel.add(createGroupButton);
        groupButtonsPanel.add(editGroupButton);
        groupButtonsPanel.add(deleteGroupButton);

        studyGroupsPanel.add(groupButtonsPanel, BorderLayout.SOUTH);


        peerGroupsCard.add(studyGroupsPanel, BorderLayout.CENTER);

        contentPanel.add(peerGroupsCard, "peerGroups");

        panel.add(contentPanel, BorderLayout.CENTER);
        return panel;
    }

    private JPanel createMentorsTab() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // My Mentors Section
        JPanel myMentorsPanel = new JPanel(new BorderLayout());
        myMentorsPanel.setBorder(BorderFactory.createTitledBorder("My Mentors"));
        myMentorsPanel.setOpaque(false);

        DefaultListModel<User> myMentorsModel = new DefaultListModel<>();
        mentorsList = new JList<>(myMentorsModel); // This is the list of mentors the student already has
        mentorsList.setCellRenderer(new MentorListCellRenderer());
        JScrollPane myMentorsScrollPane = new JScrollPane(mentorsList);
        myMentorsPanel.add(myMentorsScrollPane, BorderLayout.CENTER);

        // Available Mentors Section
        JPanel availableMentorsPanel = new JPanel(new BorderLayout());
        availableMentorsPanel.setBorder(BorderFactory.createTitledBorder("Available Mentors"));
        availableMentorsPanel.setOpaque(false);

        DefaultListModel<User> allMentorsModel = new DefaultListModel<>();
        allMentorsList = new JList<>(allMentorsModel); // This is the list of all mentors
        allMentorsList.setCellRenderer(new MentorListCellRenderer());
        JScrollPane allMentorsScrollPane = new JScrollPane(allMentorsList);
        availableMentorsPanel.add(allMentorsScrollPane, BorderLayout.CENTER);

        // Mentor Action Buttons
        JPanel mentorActionButtonsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        mentorActionButtonsPanel.setOpaque(false);

        addMentorButton = new JButton("Add Selected Mentor");
        addMentorButton.setBackground(new Color(65, 105, 225)); // RoyalBlue
        addMentorButton.setForeground(Color.WHITE);
        mentorActionButtonsPanel.add(addMentorButton);

        availableMentorsPanel.add(mentorActionButtonsPanel, BorderLayout.SOUTH);


        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, myMentorsPanel, availableMentorsPanel);
        splitPane.setResizeWeight(0.5);
        panel.add(splitPane, BorderLayout.CENTER);

        return panel;
    }


    // Custom cell renderer for Study Groups
    private static class StudyGroupListCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                    boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof StudyGroup) {
                StudyGroup group = (StudyGroup) value;
                // Assuming StudyGroup has a getMemberIds() method that returns a List<Integer>
                // and you want to display the count of members.
                int memberCount = (group.getMemberIds() != null) ? group.getMemberIds().size() : 0;
                setText(String.format("%s (%d members)", group.getName(), memberCount));
                setToolTipText(group.getDescription());
            }
            return this;
        }
    }

    // Custom cell renderer for Mentors
    private static class MentorListCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                    boolean isSelected, boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof User) {
                User mentor = (User) value;
                setText(String.format("%s (%s)", mentor.getName(), mentor.getEmail()));
                setToolTipText("Specialization: Programming"); // Placeholder
            }
            return this;
        }
    }

    public void displayCourses(List<Course> courses) {
        DefaultTableModel model = (DefaultTableModel) coursesTable.getModel();
        model.setRowCount(0);

        for (Course course : courses) {
            model.addRow(new Object[]{
                course.getCourseId(),
                course.getTitle(),
                course.getDescription(),
                "0%"
            });
        }
    }

    public void displayAssignments(List<Assignment> assignments) {
        String[] columnNames = {"Assignment ID", "Course", "Title", "Due Date", "Status"};
        Object[][] data = new Object[assignments.size()][5];

        for (int i = 0; i < assignments.size(); i++) {
            Assignment assignment = assignments.get(i);
            data[i][0] = assignment.getAssignmentId();
            data[i][1] = "Course Name";
            data[i][2] = assignment.getTitle();
            data[i][3] = assignment.getDueDate();
            data[i][4] = "Not Submitted";
        }

        assignmentsTable.setModel(new DefaultTableModel(data, columnNames));
    }

    public void populateMyStudyGroups(List<StudyGroup> groups) {
        DefaultListModel<StudyGroup> model = (DefaultListModel<StudyGroup>) groupsList.getModel();
        model.clear();
        for (StudyGroup group : groups) {
            model.addElement(group);
        }
    }

    public void populateMyMentors(List<User> mentors) {
        DefaultListModel<User> model = (DefaultListModel<User>) mentorsList.getModel();
        model.clear();
        for (User mentor : mentors) {
            model.addElement(mentor);
        }
    }

    public void populateAllMentors(List<User> mentors) {
        DefaultListModel<User> model = (DefaultListModel<User>) allMentorsList.getModel();
        model.clear();
        for (User mentor : mentors) {
            model.addElement(mentor);
        }
    }

    public void addSubmitAssignmentListener(ActionListener listener) {
        submitAssignmentButton.addActionListener(listener);
    }

    public void addViewPeerReviewsListener(ActionListener listener) {
        viewPeerReviewsButton.addActionListener(listener);
    }

    // Study Group Listeners
    public void addCreateGroupListener(ActionListener listener) {
        createGroupButton.addActionListener(listener);
    }

    public void addEditGroupListener(ActionListener listener) {
        editGroupButton.addActionListener(listener);
    }

    public void addDeleteGroupListener(ActionListener listener) {
        deleteGroupButton.addActionListener(listener);
    }

    // Mentor Listeners
    public void addAddMentorListener(ActionListener listener) {
        addMentorButton.addActionListener(listener);
    }

    public int getSelectedCourseId() {
        int selectedRow = coursesTable.getSelectedRow();
        if (selectedRow >= 0) {
            return (int) coursesTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }

    public int getSelectedAssignmentId() {
        int selectedRow = assignmentsTable.getSelectedRow();
        if (selectedRow >= 0) {
            return (int) assignmentsTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }

    public StudyGroup getSelectedStudyGroup() {
        return groupsList.getSelectedValue();
    }

    public User getSelectedAvailableMentor() {
        return allMentorsList.getSelectedValue();
    }
}
