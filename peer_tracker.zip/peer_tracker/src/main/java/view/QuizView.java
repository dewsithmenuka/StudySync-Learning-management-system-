package view;

import controller.QuizController;
import model.Question;
import model.Quiz;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class QuizView extends JFrame {
    private QuizController controller;
    private Quiz quiz;
    private List<JComponent> answerComponents;
    private int currentQuestionIndex;
    
    public QuizView(QuizController controller, Quiz quiz) {
        this.controller = controller;
        this.quiz = quiz;
        this.answerComponents = new ArrayList<>();
        this.currentQuestionIndex = 0;
        
        setTitle("Quiz: " + quiz.getTitle());
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        if (quiz.getTimeLimit() > 0) {
            startTimer(quiz.getTimeLimit());
        }
        
        showQuestion();
    }
    
    private void startTimer(int minutes) {
        Timer timer = new Timer(minutes * 60 * 1000, e -> {
            JOptionPane.showMessageDialog(this, "Time's up! Submitting your quiz.");
            submitQuiz();
            dispose();
        });
        timer.setRepeats(false);
        timer.start();
    }
    
    private void showQuestion() {
        getContentPane().removeAll();
        
        if (currentQuestionIndex >= quiz.getQuestions().size()) {
            showQuizSummary();
            return;
        }
        
        Question question = quiz.getQuestions().get(currentQuestionIndex);
        JPanel panel = new JPanel(new BorderLayout());
        
        // Question text
        JTextArea questionText = new JTextArea((currentQuestionIndex + 1) + ". " + question.getQuestionText());
        questionText.setEditable(false);
        questionText.setLineWrap(true);
        questionText.setWrapStyleWord(true);
        panel.add(questionText, BorderLayout.NORTH);
        
        // Answer area
        JPanel answerPanel = new JPanel();
        answerPanel.setLayout(new BoxLayout(answerPanel, BoxLayout.Y_AXIS));
        
        switch (question.getType()) {
            case MULTIPLE_CHOICE:
                ButtonGroup group = new ButtonGroup();
                for (String option : question.getOptions()) {
                    JRadioButton radioButton = new JRadioButton(option);
                    group.add(radioButton);
                    answerPanel.add(radioButton);
                    answerComponents.add(radioButton);
                }
                break;
                
            case TRUE_FALSE:
                ButtonGroup tfGroup = new ButtonGroup();
                JRadioButton trueButton = new JRadioButton("True");
                JRadioButton falseButton = new JRadioButton("False");
                tfGroup.add(trueButton);
                tfGroup.add(falseButton);
                answerPanel.add(trueButton);
                answerPanel.add(falseButton);
                answerComponents.add(trueButton);
                answerComponents.add(falseButton);
                break;
                
            case SHORT_ANSWER:
                JTextField textField = new JTextField();
                answerPanel.add(textField);
                answerComponents.add(textField);
                break;
        }
        
        panel.add(answerPanel, BorderLayout.CENTER);
        
        // Navigation buttons
        JPanel buttonPanel = new JPanel();
        if (currentQuestionIndex > 0) {
            JButton prevButton = new JButton("Previous");
            prevButton.addActionListener(e -> {
                currentQuestionIndex--;
                showQuestion();
            });
            buttonPanel.add(prevButton);
        }
        
        JButton nextButton = new JButton(
            currentQuestionIndex == quiz.getQuestions().size() - 1 ? "Submit" : "Next"
        );
        nextButton.addActionListener(e -> {
            currentQuestionIndex++;
            showQuestion();
        });
        buttonPanel.add(nextButton);
        
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(panel);
        revalidate();
        repaint();
    }
    
    private void showQuizSummary() {
        getContentPane().removeAll();
        
        List<String> answers = collectAnswers();
        int score = controller.calculateScore(quiz, answers);
        double percentage = controller.calculatePercentage(score, quiz);
        
        JPanel panel = new JPanel(new BorderLayout());
        
        JTextArea summary = new JTextArea();
        summary.append("Quiz: " + quiz.getTitle() + "\n");
        summary.append("Score: " + score + "/" + quiz.getTotalPoints() + "\n");
        summary.append(String.format("Percentage: %.2f%%\n", percentage));
        
        // Show correct answers for review
        summary.append("\nReview:\n");
        for (int i = 0; i < quiz.getQuestions().size(); i++) {
            Question q = quiz.getQuestions().get(i);
            summary.append("\nQ" + (i + 1) + ": " + q.getQuestionText() + "\n");
            summary.append("Your answer: " + (i < answers.size() ? answers.get(i) : "No answer") + "\n");
            summary.append("Correct answer: " + q.getCorrectAnswer() + "\n");
            if (q.getExplanation() != null && !q.getExplanation().isEmpty()) {
                summary.append("Explanation: " + q.getExplanation() + "\n");
            }
        }
        
        summary.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(summary);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        panel.add(closeButton, BorderLayout.SOUTH);
        
        add(panel);
        revalidate();
        repaint();
    }
    
    private List<String> collectAnswers() {
        List<String> answers = new ArrayList<>();
        for (JComponent component : answerComponents) {
            if (component instanceof JRadioButton) {
                JRadioButton radio = (JRadioButton) component;
                if (radio.isSelected()) {
                    answers.add(radio.getText());
                }
            } else if (component instanceof JTextField) {
                answers.add(((JTextField) component).getText());
            }
        }
        return answers;
    }
    
    private void submitQuiz() {
        List<String> answers = collectAnswers();
        int score = controller.calculateScore(quiz, answers);
        // Save results to database
        // Notify teacher
        // Update student progress
    }
}