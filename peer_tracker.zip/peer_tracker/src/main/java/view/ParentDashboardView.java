package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import model.User;
import model.Course;
import model.StudentProgress; // Import StudentProgress
import model.Message; // Import Message model
import javax.swing.table.DefaultTableModel; // Import DefaultTableModel

public class ParentDashboardView extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable childrenTable;
    private JButton linkChildButton, viewProgressButton;
    private JButton contactTeacherButton, viewFeedbackButton;
    private JTextField searchField;
    private JButton searchStudentsButton; // Added search button
    private JTable searchResultsTable; // Added search results table
    private JButton viewStudentDetailsButton; // Added button to view student details

    // Progress Tracking Tab components
    private JTable progressTable;
    private JComboBox<String> childFilterComboBox; // Filter for progress by child
    private JButton refreshProgressButton;

    // Message Tab components
    private JList<User> teacherList; // List of teachers to message
    private JTextArea conversationArea; // Displays messages
    private JTextField messageInputField; // Input for new message
    private JButton sendMessageButton; // Button to send message

    public ParentDashboardView() {
        setTitle("Parent Dashboard - Peer-to-Peer Learning Tracker");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                Color color1 = new Color(153, 50, 204); // DarkOrchid
                Color color2 = new Color(221, 160, 221); // Plum
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setOpaque(false);
        JLabel titleLabel = new JLabel("Parent Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);

        tabbedPane = new JTabbedPane();
        tabbedPane.setOpaque(false);

        JPanel childrenPanel = createChildrenPanel();
        tabbedPane.addTab("My Children", childrenPanel);

        JPanel progressPanel = createProgressPanel();
        tabbedPane.addTab("Progress Tracking", progressPanel);

        JPanel messagesPanel = createMessagesPanel();
        tabbedPane.addTab("Messages", messagesPanel);

        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        add(mainPanel);
    }

    private JPanel createChildrenPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);

        searchField = new JTextField(20);
        searchStudentsButton = new JButton("Search Student"); // Renamed for clarity
        searchStudentsButton.setBackground(new Color(75, 0, 130)); // Indigo
        searchStudentsButton.setForeground(Color.WHITE);

        searchPanel.add(new JLabel("Search by Name/Email:"));
        searchPanel.add(searchField);
        searchPanel.add(searchStudentsButton);

        // Search Results Table
        String[] searchResultColumnNames = {"User ID", "Name", "Email", "Role"};
        searchResultsTable = new JTable(new DefaultTableModel(searchResultColumnNames, 0));
        searchResultsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane searchResultsScrollPane = new JScrollPane(searchResultsTable);

        // Children table (for linked children)
        String[] columnNames = {"Student ID", "Name", "Email", "Grade Level", "Courses"};
        childrenTable = new JTable(new DefaultTableModel(columnNames, 0));
        childrenTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane childrenScrollPane = new JScrollPane(childrenTable);

        // Combine search results and linked children tables
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, searchResultsScrollPane, childrenScrollPane);
        splitPane.setResizeWeight(0.5); // Adjust as needed

        // Button panel for search results
        JPanel searchResultButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchResultButtonPanel.setOpaque(false);
        viewStudentDetailsButton = new JButton("View Student Details");
        viewStudentDetailsButton.setBackground(new Color(100, 149, 237)); // CornflowerBlue
        viewStudentDetailsButton.setForeground(Color.WHITE);
        viewStudentDetailsButton.setEnabled(false); // Initially disabled
        searchResultButtonPanel.add(viewStudentDetailsButton);

        // Button panel for linked children
        JPanel linkedChildrenButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        linkedChildrenButtonPanel.setOpaque(false);

        linkChildButton = new JButton("Link to My Account");
        linkChildButton.setBackground(new Color(148, 0, 211)); // DarkViolet
        linkChildButton.setForeground(Color.WHITE);
        linkChildButton.setEnabled(false); // Initially disabled, enabled after search selection

        viewProgressButton = new JButton("View Progress");
        viewProgressButton.setBackground(new Color(186, 85, 211)); // MediumOrchid
        viewProgressButton.setForeground(Color.WHITE);

        contactTeacherButton = new JButton("Contact Teacher");
        contactTeacherButton.setBackground(new Color(147, 112, 219)); // MediumPurple
        contactTeacherButton.setForeground(Color.WHITE);

        viewFeedbackButton = new JButton("View Feedback");
        viewFeedbackButton.setBackground(new Color(138, 43, 226)); // BlueViolet
        viewFeedbackButton.setForeground(Color.WHITE);

        linkedChildrenButtonPanel.add(linkChildButton);
        linkedChildrenButtonPanel.add(viewProgressButton);
        linkedChildrenButtonPanel.add(contactTeacherButton);
        linkedChildrenButtonPanel.add(viewFeedbackButton);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(splitPane, BorderLayout.CENTER);
        centerPanel.add(searchResultButtonPanel, BorderLayout.NORTH); // Buttons for search results

        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(centerPanel, BorderLayout.CENTER);
        panel.add(linkedChildrenButtonPanel, BorderLayout.SOUTH); // Buttons for linked children

        // Add selection listener to searchResultsTable to enable/disable buttons
        searchResultsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                boolean rowSelected = searchResultsTable.getSelectedRow() != -1;
                viewStudentDetailsButton.setEnabled(rowSelected);
                linkChildButton.setEnabled(rowSelected);
            }
        });

        return panel;
    }

    private JPanel createProgressPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        // Filter panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.setOpaque(false);

        filterPanel.add(new JLabel("Filter by Child:"));
        childFilterComboBox = new JComboBox<>();
        childFilterComboBox.setPreferredSize(new Dimension(200, 25));
        filterPanel.add(childFilterComboBox);

        refreshProgressButton = new JButton("Refresh Progress");
        refreshProgressButton.setBackground(new Color(70, 130, 180)); // SteelBlue
        refreshProgressButton.setForeground(Color.WHITE);
        filterPanel.add(refreshProgressButton);

        // Progress table
        String[] progressColumns = {"Child Name", "Course", "Completed Assignments", "Average Score", "Last Active Date", "Overall Progress"};
        progressTable = new JTable(new DefaultTableModel(progressColumns, 0)) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 5 ? Integer.class : Object.class; // Overall Progress as Integer for ProgressBarRenderer
            }
        };
        progressTable.setDefaultRenderer(Integer.class, new ProgressBarRenderer()); // Custom renderer for progress bar

        JScrollPane progressScrollPane = new JScrollPane(progressTable);

        panel.add(filterPanel, BorderLayout.NORTH);
        panel.add(progressScrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createMessagesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        // Left panel for teacher list
        JPanel teacherListPanel = new JPanel(new BorderLayout());
        teacherListPanel.setBorder(BorderFactory.createTitledBorder("Teachers"));
        teacherList = new JList<>();
        teacherList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        teacherListPanel.add(new JScrollPane(teacherList), BorderLayout.CENTER);

        // Right panel for conversation and message input
        JPanel conversationPanel = new JPanel(new BorderLayout());
        conversationPanel.setBorder(BorderFactory.createTitledBorder("Conversation"));
        conversationArea = new JTextArea();
        conversationArea.setEditable(false);
        conversationArea.setLineWrap(true);
        conversationArea.setWrapStyleWord(true);
        conversationPanel.add(new JScrollPane(conversationArea), BorderLayout.CENTER);

        JPanel messageInputPanel = new JPanel(new BorderLayout());
        messageInputField = new JTextField();
        sendMessageButton = new JButton("Send");
        messageInputPanel.add(messageInputField, BorderLayout.CENTER);
        messageInputPanel.add(sendMessageButton, BorderLayout.EAST);
        conversationPanel.add(messageInputPanel, BorderLayout.SOUTH);

        // Split pane to divide teacher list and conversation
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, teacherListPanel, conversationPanel);
        splitPane.setResizeWeight(0.3); // 30% for teacher list, 70% for conversation

        panel.add(splitPane, BorderLayout.CENTER);
        return panel;
    }

    // Methods to update tables
    public void displayChildren(List<User> children) {
        String[] columnNames = {"Student ID", "Name", "Email", "Grade Level", "Courses"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        for (User child : children) {
            model.addRow(new Object[]{
                child.getUserId(),
                child.getName(),
                child.getEmail(),
                "N/A", // Placeholder for Grade Level
                "N/A" // Placeholder for Course Count
            });
        }
        childrenTable.setModel(model);
        populateChildFilter(children); // Populate filter for progress tab
    }

    public void displaySearchResults(List<User> students) {
        String[] columnNames = {"User ID", "Name", "Email", "Role"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        for (User student : students) {
            model.addRow(new Object[]{
                student.getUserId(),
                student.getName(),
                student.getEmail(),
                student.getRole()
            });
        }
        searchResultsTable.setModel(model);
    }

    public void displayChildProgress(List<StudentProgress> progressList) {
        DefaultTableModel model = (DefaultTableModel) progressTable.getModel();
        model.setRowCount(0);

        for (StudentProgress progress : progressList) {
            model.addRow(new Object[]{
                progress.getStudentName(),
                progress.getCourseName(),
                progress.getCompletedAssignments() + "/" + progress.getTotalAssignments(),
                String.format("%.1f%%", progress.getAverageScore()),
                progress.getLastActiveDate(),
                progress.getProgressPercentage()
            });
        }
    }

    public void populateChildFilter(List<User> children) {
        childFilterComboBox.removeAllItems();
        childFilterComboBox.addItem("All Children");
        for (User child : children) {
            childFilterComboBox.addItem(child.getName());
        }
    }

    // New methods for message tab
    public void displayTeachers(List<User> teachers) {
        teacherList.setListData(teachers.toArray(new User[0]));
    }

    public void displayConversation(List<Message> messages) {
        conversationArea.setText(""); // Clear previous conversation
        for (Message message : messages) {
            conversationArea.append(String.format("[%s] %s: %s\n",
                message.getSentAt().toLocalTime().toString(),
                message.getSenderId() == getLoggedInUserId() ? "You" : "Teacher", // Assuming logged in user ID is available
                message.getContent()));
        }
    }

    public String getMessageInput() {
        return messageInputField.getText();
    }

    public void clearMessageInput() {
        messageInputField.setText("");
    }

    public User getSelectedTeacher() {
        return teacherList.getSelectedValue();
    }

    // Action listeners
    public void addLinkChildListener(ActionListener listener) {
        linkChildButton.addActionListener(listener);
    }

    public void addViewProgressListener(ActionListener listener) {
        viewProgressButton.addActionListener(listener);
    }

    public void addContactTeacherListener(ActionListener listener) {
        contactTeacherButton.addActionListener(listener);
    }

    public void addViewFeedbackListener(ActionListener listener) {
        viewFeedbackButton.addActionListener(listener);
    }

    public void addSearchStudentListener(ActionListener listener) {
        searchStudentsButton.addActionListener(listener);
    }

    public void addViewStudentDetailsListener(ActionListener listener) {
        viewStudentDetailsButton.addActionListener(listener);
    }

    public void addRefreshProgressListener(ActionListener listener) {
        refreshProgressButton.addActionListener(listener);
    }

    // New action listeners for message tab
    public void addSendMessageListener(ActionListener listener) {
        sendMessageButton.addActionListener(listener);
    }

    public void addTeacherSelectionListener(javax.swing.event.ListSelectionListener listener) {
        teacherList.addListSelectionListener(listener);
    }

    // Getters
    public String getSearchTerm() {
        return searchField.getText();
    }

    public int getSelectedChildId() {
        int selectedRow = childrenTable.getSelectedRow();
        if (selectedRow >= 0) {
            return (int) childrenTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }

    public int getSelectedStudentIdFromSearchResults() {
        int selectedRow = searchResultsTable.getSelectedRow();
        if (selectedRow >= 0) {
            return (int) searchResultsTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }

    public String getSelectedChildFilter() {
        return (String) childFilterComboBox.getSelectedItem();
    }

    // Placeholder for logged in user ID - this should be set by the controller
    private int loggedInUserId;
    public void setLoggedInUserId(int userId) {
        this.loggedInUserId = userId;
    }
    public int getLoggedInUserId() {
        return this.loggedInUserId;
    }

    // Progress bar renderer for the table
    private class ProgressBarRenderer extends JProgressBar implements javax.swing.table.TableCellRenderer {
        public ProgressBarRenderer() {
            super(0, 100);
            setStringPainted(true);
        }

        public java.awt.Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected, boolean hasFocus,
            int row, int column) {
            int progress = (value instanceof Integer) ? (Integer) value : 0;
            setValue(progress);
            if (progress < 30) {
                setForeground(Color.RED);
            } else if (progress < 70) {
                setForeground(Color.ORANGE);
            } else {
                setForeground(new Color(0, 180, 0));
            }
            return this;
        }
    }
}
