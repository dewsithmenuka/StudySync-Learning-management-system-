package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import model.User;
import model.Resource; // Import Resource model
import model.Session; // Import Session model
import javax.swing.table.DefaultTableModel;

public class MentorDashboardView extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable menteesTable;
    private JButton sendMessageButton, scheduleSessionButton;
    private JButton shareResourceButton, viewProgressButton;

    // Resource Management UI elements
    private JTable resourcesTable;
    private JButton addResourceButton, editResourceButton, deleteResourceButton;

    // Session Management UI elements
    private JTable sessionsTable;
    private JButton addSessionButton, editSessionButton, deleteSessionButton;
    
    public MentorDashboardView() {
        setTitle("Mentor Dashboard - Peer-to-Peer Learning Tracker");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Main panel with gradient
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                Color color1 = new Color(210, 105, 30); // Chocolate
                Color color2 = new Color(244, 164, 96); // SandyBrown
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Header panel
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setOpaque(false);
        JLabel titleLabel = new JLabel("Mentor Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Tabbed pane for different functions
        tabbedPane = new JTabbedPane();
        tabbedPane.setOpaque(false);
        
        // Mentees Tab
        JPanel menteesPanel = createMenteesPanel();
        tabbedPane.addTab("My Mentees", menteesPanel);
        
        // Resources Tab
        JPanel resourcesPanel = createResourcesPanel();
        tabbedPane.addTab("Resources", resourcesPanel);
        
        // Schedule Tab
        JPanel schedulePanel = createSchedulePanel();
        tabbedPane.addTab("Schedule", schedulePanel);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JPanel createMenteesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Mentees table
        String[] columnNames = {"Student ID", "Name", "Email", "Courses", "Progress"};
        Object[][] data = {}; // Empty for now
        menteesTable = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(menteesTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);
        
        sendMessageButton = new JButton("Send Message");
        sendMessageButton.setBackground(new Color(65, 105, 225)); // RoyalBlue
        sendMessageButton.setForeground(Color.WHITE);
        
        scheduleSessionButton = new JButton("Schedule Session");
        scheduleSessionButton.setBackground(new Color(0, 100, 0)); // DarkGreen
        scheduleSessionButton.setForeground(Color.WHITE);
        
        viewProgressButton = new JButton("View Progress");
        viewProgressButton.setBackground(new Color(139, 69, 19)); // SaddleBrown
        viewProgressButton.setForeground(Color.WHITE);
        
        shareResourceButton = new JButton("Share Resource");
        shareResourceButton.setBackground(new Color(47, 79, 79)); // DarkSlateGray
        shareResourceButton.setForeground(Color.WHITE);
        
        buttonPanel.add(sendMessageButton);
        buttonPanel.add(scheduleSessionButton);
        buttonPanel.add(viewProgressButton);
        buttonPanel.add(shareResourceButton);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createResourcesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        // Resources table
        String[] columnNames = {"ID", "Title", "Description", "File Path", "Upload Date"};
        resourcesTable = new JTable(new DefaultTableModel(columnNames, 0));
        resourcesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(resourcesTable);

        // Button panel for resource management
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);

        addResourceButton = new JButton("Add Resource");
        addResourceButton.setBackground(new Color(34, 139, 34)); // ForestGreen
        addResourceButton.setForeground(Color.WHITE);

        editResourceButton = new JButton("Edit Resource");
        editResourceButton.setBackground(new Color(255, 140, 0)); // DarkOrange
        editResourceButton.setForeground(Color.WHITE);

        deleteResourceButton = new JButton("Delete Resource");
        deleteResourceButton.setBackground(new Color(220, 20, 60)); // Crimson
        deleteResourceButton.setForeground(Color.WHITE);

        buttonPanel.add(addResourceButton);
        buttonPanel.add(editResourceButton);
        buttonPanel.add(deleteResourceButton);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }
    
    private JPanel createSchedulePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        // Sessions table
        String[] columnNames = {"ID", "Mentee", "Title", "Start Time", "End Time", "Location"};
        sessionsTable = new JTable(new DefaultTableModel(columnNames, 0));
        sessionsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(sessionsTable);

        // Button panel for session management
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);

        addSessionButton = new JButton("Add Session");
        addSessionButton.setBackground(new Color(34, 139, 34)); // ForestGreen
        addSessionButton.setForeground(Color.WHITE);

        editSessionButton = new JButton("Edit Session");
        editSessionButton.setBackground(new Color(255, 140, 0)); // DarkOrange
        editSessionButton.setForeground(Color.WHITE);

        deleteSessionButton = new JButton("Delete Session");
        deleteSessionButton.setBackground(new Color(220, 20, 60)); // Crimson
        deleteSessionButton.setForeground(Color.WHITE);

        buttonPanel.add(addSessionButton);
        buttonPanel.add(editSessionButton);
        buttonPanel.add(deleteSessionButton);

        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        return panel;
    }
    
    // Methods to update tables
    public void displayMentees(List<User> mentees) {
        String[] columnNames = {"Student ID", "Name", "Email", "Courses", "Progress"};
        Object[][] data = new Object[mentees.size()][5];
        
        for (int i = 0; i < mentees.size(); i++) {
            User mentee = mentees.get(i);
            data[i][0] = mentee.getUserId();
            data[i][1] = mentee.getName();
            data[i][2] = mentee.getEmail();
            data[i][3] = "0"; // Will be replaced with actual course count
            data[i][4] = "0%"; // Will be replaced with actual progress
        }
        
        menteesTable.setModel(new javax.swing.table.DefaultTableModel(data, columnNames));
    }

    public void displayResources(List<Resource> resources) {
        DefaultTableModel model = (DefaultTableModel) resourcesTable.getModel();
        model.setRowCount(0); // Clear existing data
        for (Resource resource : resources) {
            model.addRow(new Object[]{
                resource.getResourceId(),
                resource.getTitle(),
                resource.getDescription(),
                resource.getFilePath(),
                resource.getUploadDate()
            });
        }
    }

    public void displaySessions(List<Session> sessions) {
        DefaultTableModel model = (DefaultTableModel) sessionsTable.getModel();
        model.setRowCount(0); // Clear existing data
        for (Session session : sessions) {
            model.addRow(new Object[]{
                session.getSessionId(),
                session.getMenteeId(), // This should ideally be mentee name, will need a join or lookup
                session.getTitle(),
                session.getStartTime(),
                session.getEndTime(),
                session.getLocation()
            });
        }
    }
    
    // Action listeners for Mentees tab
    public void addSendMessageListener(ActionListener listener) {
        sendMessageButton.addActionListener(listener);
    }
    
    public void addScheduleSessionListener(ActionListener listener) {
        scheduleSessionButton.addActionListener(listener);
    }
    
    public void addViewProgressListener(ActionListener listener) {
        viewProgressButton.addActionListener(listener);
    }
    
    public void addShareResourceListener(ActionListener listener) {
        shareResourceButton.addActionListener(listener);
    }

    // Action listeners for Resources tab
    public void addAddResourceListener(ActionListener listener) {
        addResourceButton.addActionListener(listener);
    }

    public void addEditResourceListener(ActionListener listener) {
        editResourceButton.addActionListener(listener);
    }

    public void addDeleteResourceListener(ActionListener listener) {
        deleteResourceButton.addActionListener(listener);
    }

    // Action listeners for Schedule tab
    public void addAddSessionListener(ActionListener listener) {
        addSessionButton.addActionListener(listener);
    }

    public void addEditSessionListener(ActionListener listener) {
        editSessionButton.addActionListener(listener);
    }

    public void addDeleteSessionListener(ActionListener listener) {
        deleteSessionButton.addActionListener(listener);
    }
    
    // Getters
    public int getSelectedMenteeId() {
        int selectedRow = menteesTable.getSelectedRow();
        if (selectedRow >= 0) {
            return (int) menteesTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }

    public int getSelectedResourceId() {
        int selectedRow = resourcesTable.getSelectedRow();
        if (selectedRow >= 0) {
            return (int) resourcesTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }

    public int getSelectedSessionId() {
        int selectedRow = sessionsTable.getSelectedRow();
        if (selectedRow >= 0) {
            return (int) sessionsTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }
}
