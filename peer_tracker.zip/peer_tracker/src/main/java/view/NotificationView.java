package view;

import controller.NotificationController;
import model.Notification;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class NotificationView extends JFrame {
    private NotificationController controller;
    private int userId;
    
    private JList<Notification> notificationList;
    private JButton markAsReadButton;
    private JButton closeButton;
    
    public NotificationView(NotificationController controller, int userId) {
        this.controller = controller;
        this.userId = userId;
        
        setTitle("Notifications");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        initUI();
        loadNotifications();
    }
    
    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Notification list with custom renderer
        notificationList = new JList<>();
        notificationList.setCellRenderer(new NotificationRenderer());
        JScrollPane scrollPane = new JScrollPane(notificationList);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        markAsReadButton = new JButton("Mark as Read");
        closeButton = new JButton("Close");
        
        markAsReadButton.addActionListener(new MarkAsReadListener());
        closeButton.addActionListener(e -> dispose());
        
        buttonPanel.add(markAsReadButton);
        buttonPanel.add(closeButton);
        
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        mainPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(mainPanel);
    }
    
    private void loadNotifications() {
        List<Notification> notifications = controller.getUnreadNotifications(userId);
        notificationList.setListData(notifications.toArray(new Notification[0]));
    }
    
    class NotificationRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, 
                                                     int index, boolean isSelected, 
                                                     boolean cellHasFocus) {
            super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
            if (value instanceof Notification) {
                Notification notification = (Notification) value;
                setText(String.format("<html><b>%s</b><br>%s</html>", 
                    notification.getType(), 
                    notification.getMessage()));
                
                if (isSelected) {
                    setBackground(new Color(220, 240, 255));
                } else {
                    setBackground(notification.isRead() ? Color.WHITE : new Color(255, 255, 200));
                }
            }
            return this;
        }
    }
    
    class MarkAsReadListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            Notification selected = notificationList.getSelectedValue();
            if (selected != null) {
                controller.markAsRead(selected.getNotificationId());
                loadNotifications(); // Refresh the list
            } else {
                JOptionPane.showMessageDialog(NotificationView.this, 
                    "Please select a notification first", 
                    "No Notification Selected", 
                    JOptionPane.WARNING_MESSAGE);
            }
        }
    }
}