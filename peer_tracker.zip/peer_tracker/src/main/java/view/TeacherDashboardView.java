package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import model.Course;
import model.Assignment;
import model.StudentProgress;
import model.User; // Import User model
import javax.swing.table.DefaultTableModel;

public class TeacherDashboardView extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable coursesTable;
    private JTable assignmentsTable;
    private JProgressBar progressBar;
    private JButton createAssignmentButton, gradeAssignmentsButton;
    private JButton viewSubmissionsButton, managePeerReviewsButton;
    private JButton addCourseButton, editCourseButton, deleteCourseButton;
    private JTable progressTable;
    private JButton refreshProgressButton;
    private JComboBox<String> courseFilterComboBox;

    // New UI elements for student management
    private JTextField studentSearchField;
    private JButton searchStudentsButton;
    private JTable searchResultsTable;
    private JButton addStudentToCourseButton;

    public TeacherDashboardView() {
        setTitle("Teacher Dashboard - Peer-to-Peer Learning Tracker");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Main panel with gradient
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                Color color1 = new Color(46, 139, 87); // SeaGreen
                Color color2 = new Color(144, 238, 144); // LightGreen
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Header panel
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setOpaque(false);
        JLabel titleLabel = new JLabel("Teacher Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Tabbed pane for different functions
        tabbedPane = new JTabbedPane();
        tabbedPane.setOpaque(false);
        
        // My Courses Tab
        JPanel coursesPanel = createCoursesPanel();
        tabbedPane.addTab("My Courses", coursesPanel);
        
        // Assignments Tab
        JPanel assignmentsPanel = createAssignmentsPanel();
        tabbedPane.addTab("Assignments", assignmentsPanel);
        
        // Student Progress Tab
        JPanel progressPanel = createProgressPanel();
        tabbedPane.addTab("Student Progress", progressPanel);

        // Student Management Tab
        JPanel studentManagementPanel = createStudentManagementPanel();
        tabbedPane.addTab("Student Management", studentManagementPanel);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JPanel createCoursesPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Courses table
        String[] columnNames = {"Course ID", "Title", "Description", "Students Enrolled"};
        Object[][] data = {}; // Empty for now
        coursesTable = new JTable(data, columnNames);
        coursesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(coursesTable);

        // Button panel for course management
        JPanel courseButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        courseButtonPanel.setOpaque(false);

        addCourseButton = new JButton("Add Course");
        addCourseButton.setBackground(new Color(34, 139, 34)); // ForestGreen
        addCourseButton.setForeground(Color.WHITE);

        editCourseButton = new JButton("Edit Course");
        editCourseButton.setBackground(new Color(255, 140, 0)); // DarkOrange
        editCourseButton.setForeground(Color.WHITE);

        deleteCourseButton = new JButton("Delete Course");
        deleteCourseButton.setBackground(new Color(220, 20, 60)); // Crimson
        deleteCourseButton.setForeground(Color.WHITE);

        courseButtonPanel.add(addCourseButton);
        courseButtonPanel.add(editCourseButton);
        courseButtonPanel.add(deleteCourseButton);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(courseButtonPanel, BorderLayout.SOUTH);
        return panel;
    }
    
    private JPanel createAssignmentsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Assignments table
        String[] columnNames = {"Assignment ID", "Course", "Title", "Due Date", "Submissions"};
        Object[][] data = {}; // Empty for now
        assignmentsTable = new JTable(data, columnNames);
        JScrollPane scrollPane = new JScrollPane(assignmentsTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);
        
        createAssignmentButton = new JButton("Create Assignment");
        createAssignmentButton.setBackground(new Color(0, 128, 128)); // Teal
        createAssignmentButton.setForeground(Color.WHITE);
        
        gradeAssignmentsButton = new JButton("Grade Assignments");
        gradeAssignmentsButton.setBackground(new Color(139, 0, 139)); // DarkMagenta
        gradeAssignmentsButton.setForeground(Color.WHITE);
        
        viewSubmissionsButton = new JButton("View Submissions");
        viewSubmissionsButton.setBackground(new Color(72, 61, 139)); // DarkSlateBlue
        viewSubmissionsButton.setForeground(Color.WHITE);
        
        managePeerReviewsButton = new JButton("Manage Peer Reviews");
        managePeerReviewsButton.setBackground(new Color(85, 107, 47)); // DarkOliveGreen
        managePeerReviewsButton.setForeground(Color.WHITE);
        
        buttonPanel.add(createAssignmentButton);
        buttonPanel.add(gradeAssignmentsButton);
        buttonPanel.add(viewSubmissionsButton);
        buttonPanel.add(managePeerReviewsButton);
        
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createProgressPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Filter panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.setOpaque(false);
        
        filterPanel.add(new JLabel("Filter by Course:"));
        courseFilterComboBox = new JComboBox<>();
        courseFilterComboBox.setPreferredSize(new Dimension(200, 25));
        filterPanel.add(courseFilterComboBox);
        
        refreshProgressButton = new JButton("Refresh Progress");
        refreshProgressButton.setBackground(new Color(70, 130, 180)); // SteelBlue
        refreshProgressButton.setForeground(Color.WHITE);
        filterPanel.add(refreshProgressButton);
        
        // Progress table
        String[] progressColumns = {"Student ID", "Student Name", "Course", 
                                   "Completed", "Avg Score", "Last Active", "Progress"};
        progressTable = new JTable(new DefaultTableModel(progressColumns, 0)) {
            @Override
            public Class<?> getColumnClass(int column) {
                return column == 6 ? Integer.class : Object.class;
            }
        };
        
        // Render progress as progress bars
        progressTable.setDefaultRenderer(Integer.class, new ProgressBarRenderer());
        
        JScrollPane progressScrollPane = new JScrollPane(progressTable);
        
        panel.add(filterPanel, BorderLayout.NORTH);
        panel.add(progressScrollPane, BorderLayout.CENTER);
        
        return panel;
    }

    private JPanel createStudentManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);

        // Search student panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);

        studentSearchField = new JTextField(20);
        searchStudentsButton = new JButton("Search Students");
        searchStudentsButton.setBackground(new Color(65, 105, 225)); // RoyalBlue
        searchStudentsButton.setForeground(Color.WHITE);

        searchPanel.add(new JLabel("Search Student (Name/Email):"));
        searchPanel.add(studentSearchField);
        searchPanel.add(searchStudentsButton);

        // Search results table
        String[] searchResultColumnNames = {"User ID", "Name", "Email", "Role"};
        searchResultsTable = new JTable(new DefaultTableModel(searchResultColumnNames, 0));
        searchResultsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane searchResultsScrollPane = new JScrollPane(searchResultsTable);

        // Add student to course button
        addStudentToCourseButton = new JButton("Add Selected Student to Course");
        addStudentToCourseButton.setBackground(new Color(34, 139, 34)); // ForestGreen
        addStudentToCourseButton.setForeground(Color.WHITE);

        JPanel addStudentButtonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        addStudentButtonPanel.setOpaque(false);
        addStudentButtonPanel.add(addStudentToCourseButton);

        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(searchResultsScrollPane, BorderLayout.CENTER);
        panel.add(addStudentButtonPanel, BorderLayout.SOUTH);

        return panel;
    }
    
    // Display methods
    public void displayCourses(List<Course> courses) {
        String[] columnNames = {"Course ID", "Title", "Description", "Students Enrolled"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);
        
        for (Course course : courses) {
            model.addRow(new Object[]{
                course.getCourseId(),
                course.getTitle(),
                course.getDescription(),
                "0" // Will be replaced with actual count
            });
        }
        
        coursesTable.setModel(model);
        populateCourseFilter(courses);
    }
    
    public void displayAssignments(List<Assignment> assignments) {
        String[] columnNames = {"Assignment ID", "Course", "Title", "Due Date", "Submissions"};
        Object[][] data = new Object[assignments.size()][5];
        
        for (int i = 0; i < assignments.size(); i++) {
            Assignment assignment = assignments.get(i);
            data[i][0] = assignment.getAssignmentId();
            data[i][1] = "Course Name"; // Will be replaced with actual course name
            data[i][2] = assignment.getTitle();
            data[i][3] = assignment.getDueDate();
            data[i][4] = "0/0"; // Will be replaced with actual submission count
        }
        
        assignmentsTable.setModel(new javax.swing.table.DefaultTableModel(data, columnNames));
    }
    
    public void displayStudentProgress(List<StudentProgress> progressList) {
        DefaultTableModel model = (DefaultTableModel) progressTable.getModel();
        model.setRowCount(0);
        
        for (StudentProgress progress : progressList) {
            model.addRow(new Object[]{
                progress.getStudentId(),
                progress.getStudentName(),
                progress.getCourseName(),
                progress.getCompletedAssignments() + "/" + progress.getTotalAssignments(),
                String.format("%.1f%%", progress.getAverageScore()),
                progress.getLastActiveDate(),
                progress.getProgressPercentage()
            });
        }
    }

    public void displaySearchResults(List<User> students) {
        String[] columnNames = {"User ID", "Name", "Email", "Role"};
        DefaultTableModel model = new DefaultTableModel(columnNames, 0);

        for (User student : students) {
            model.addRow(new Object[]{
                student.getUserId(),
                student.getName(),
                student.getEmail(),
                student.getRole()
            });
        }
        searchResultsTable.setModel(model);
    }
    
    public void populateCourseFilter(List<Course> courses) {
        courseFilterComboBox.removeAllItems();
        courseFilterComboBox.addItem("All Courses");
        for (Course course : courses) {
            courseFilterComboBox.addItem(course.getTitle());
        }
    }
    
    // Getters
    public int getSelectedCourseId() {
        int selectedRow = coursesTable.getSelectedRow();
        return selectedRow >= 0 ? (int) coursesTable.getValueAt(selectedRow, 0) : -1;
    }
    
    public int getSelectedAssignmentId() {
        int selectedRow = assignmentsTable.getSelectedRow();
        return selectedRow >= 0 ? (int) assignmentsTable.getValueAt(selectedRow, 0) : -1;
    }
    
    public String getSelectedCourseFilter() {
        return (String) courseFilterComboBox.getSelectedItem();
    }

    public String getStudentSearchTerm() {
        return studentSearchField.getText();
    }

    public int getSelectedStudentIdFromSearchResults() {
        int selectedRow = searchResultsTable.getSelectedRow();
        if (selectedRow >= 0) {
            return (int) searchResultsTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }
    
    // Listeners
    public void addCreateAssignmentListener(ActionListener listener) {
        createAssignmentButton.addActionListener(listener);
    }
    
    public void addGradeAssignmentsListener(ActionListener listener) {
        gradeAssignmentsButton.addActionListener(listener);
    }
    
    public void addViewSubmissionsListener(ActionListener listener) {
        viewSubmissionsButton.addActionListener(listener);
    }
    
    public void addManagePeerReviewsListener(ActionListener listener) {
        managePeerReviewsButton.addActionListener(listener);
    }
    
    public void addAddCourseListener(ActionListener listener) {
        addCourseButton.addActionListener(listener);
    }
    
    public void addEditCourseListener(ActionListener listener) {
        editCourseButton.addActionListener(listener);
    }
    
    public void addDeleteCourseListener(ActionListener listener) {
        deleteCourseButton.addActionListener(listener);
    }
    
    public void addRefreshProgressListener(ActionListener listener) {
        refreshProgressButton.addActionListener(listener);
    }

    public void addSearchStudentsListener(ActionListener listener) {
        searchStudentsButton.addActionListener(listener);
    }

    public void addAddStudentToCourseListener(ActionListener listener) {
        addStudentToCourseButton.addActionListener(listener);
    }
    
    // Progress bar renderer for the table
    private class ProgressBarRenderer extends JProgressBar implements javax.swing.table.TableCellRenderer {
        public ProgressBarRenderer() {
            super(0, 100);
            setStringPainted(true);
        }
        
        public java.awt.Component getTableCellRendererComponent(
            JTable table, Object value, boolean isSelected, boolean hasFocus, 
            int row, int column) {
            int progress = (value instanceof Integer) ? (Integer) value : 0;
            setValue(progress);
            if (progress < 30) {
                setForeground(Color.RED);
            } else if (progress < 70) {
                setForeground(Color.ORANGE);
            } else {
                setForeground(new Color(0, 180, 0));
            }
            return this;
        }
    }
}
