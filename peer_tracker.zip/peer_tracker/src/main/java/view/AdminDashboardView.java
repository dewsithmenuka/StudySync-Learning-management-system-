package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import model.User;

public class AdminDashboardView extends JFrame {
    private JTabbedPane tabbedPane;
    private JTable usersTable;
    private JButton addUserButton, editUserButton, deleteUserButton;
    private JButton assignRoleButton, assignMentorButton;
    private JComboBox<String> roleFilterComboBox;
    private JTextField searchField;
    
    public AdminDashboardView() {
        setTitle("Admin Dashboard - Peer-to-Peer Learning Tracker");
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Main panel with gradient
        JPanel mainPanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                Color color1 = new Color(70, 130, 180); // SteelBlue
                Color color2 = new Color(135, 206, 250); // LightSkyBlue
                GradientPaint gp = new GradientPaint(0, 0, color1, getWidth(), getHeight(), color2);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        
        // Header panel
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        headerPanel.setOpaque(false);
        JLabel titleLabel = new JLabel("Admin Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel);
        
        // Tabbed pane for different admin functions
        tabbedPane = new JTabbedPane();
        tabbedPane.setOpaque(false);
        
        // User Management Tab
        JPanel userManagementPanel = createUserManagementPanel();
        tabbedPane.addTab("User Management", userManagementPanel);
        
        // Course Management Tab
        JPanel courseManagementPanel = createCourseManagementPanel();
        tabbedPane.addTab("Course Management", courseManagementPanel);
        
        // System Analytics Tab
        JPanel analyticsPanel = createAnalyticsPanel();
        tabbedPane.addTab("Analytics", analyticsPanel);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JPanel createUserManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        
        // Search and filter panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setOpaque(false);
        
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        searchButton.setBackground(new Color(100, 149, 237)); // CornflowerBlue
        searchButton.setForeground(Color.WHITE);
        
        roleFilterComboBox = new JComboBox<>(new String[]{"All", "Admin", "Student", "Teacher", "Mentor", "Parent"});
        
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(new JLabel("Filter by Role:"));
        searchPanel.add(roleFilterComboBox);
        
        // Users table
        String[] columnNames = {"ID", "Name", "Email", "Role", "Phone", "Status"};
        Object[][] data = {}; // Empty for now, will be populated by controller
        usersTable = new JTable(data, columnNames);
        usersTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(usersTable);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buttonPanel.setOpaque(false);
        
        addUserButton = new JButton("Add User");
        addUserButton.setBackground(new Color(34, 139, 34)); // ForestGreen
        addUserButton.setForeground(Color.WHITE);
        
        editUserButton = new JButton("Edit User");
        editUserButton.setBackground(new Color(255, 140, 0)); // DarkOrange
        editUserButton.setForeground(Color.WHITE);
        
        deleteUserButton = new JButton("Delete User");
        deleteUserButton.setBackground(new Color(220, 20, 60)); // Crimson
        deleteUserButton.setForeground(Color.WHITE);
        
        assignRoleButton = new JButton("Assign Role");
        assignRoleButton.setBackground(new Color(138, 43, 226)); // BlueViolet
        assignRoleButton.setForeground(Color.WHITE);
        
        assignMentorButton = new JButton("Assign Mentor");
        assignMentorButton.setBackground(new Color(0, 139, 139)); // DarkCyan
        assignMentorButton.setForeground(Color.WHITE);
        
        buttonPanel.add(addUserButton);
        buttonPanel.add(editUserButton);
        buttonPanel.add(deleteUserButton);
        buttonPanel.add(assignRoleButton);
        buttonPanel.add(assignMentorButton);
        
        panel.add(searchPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(buttonPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    private JPanel createCourseManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.add(new JLabel("Course Management - To be implemented"), BorderLayout.CENTER);
        return panel;
    }
    
    private JPanel createAnalyticsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setOpaque(false);
        panel.add(new JLabel("System Analytics - To be implemented"), BorderLayout.CENTER);
        return panel;
    }
    
    // Methods to update the users table
    public void displayUsers(List<User> users) {
        String[] columnNames = {"ID", "Name", "Email", "Role", "Phone", "Status"};
        Object[][] data = new Object[users.size()][6];
        
        for (int i = 0; i < users.size(); i++) {
            User user = users.get(i);
            data[i][0] = user.getUserId();
            data[i][1] = user.getName();
            data[i][2] = user.getEmail();
            data[i][3] = user.getRole();
            data[i][4] = user.getPhone();
            data[i][5] = user.isActive() ? "Active" : "Inactive";
        }
        
        usersTable.setModel(new javax.swing.table.DefaultTableModel(data, columnNames));
    }
    
    // Action listeners
    public void addAddUserListener(ActionListener listener) {
        addUserButton.addActionListener(listener);
    }
    
    public void addEditUserListener(ActionListener listener) {
        editUserButton.addActionListener(listener);
    }
    
    public void addDeleteUserListener(ActionListener listener) {
        deleteUserButton.addActionListener(listener);
    }
    
    public void addAssignRoleListener(ActionListener listener) {
        assignRoleButton.addActionListener(listener);
    }
    
    public void addAssignMentorListener(ActionListener listener) {
        assignMentorButton.addActionListener(listener);
    }
    
    public void addSearchListener(ActionListener listener) {
        // Implement search functionality
    }
    
    public void addRoleFilterListener(ActionListener listener) {
        roleFilterComboBox.addActionListener(listener);
    }
    
    // Getters
    public int getSelectedUserId() {
        int selectedRow = usersTable.getSelectedRow();
        if (selectedRow >= 0) {
            return (int) usersTable.getValueAt(selectedRow, 0);
        }
        return -1;
    }
    
    public String getSearchTerm() {
        return searchField.getText();
    }
    
    public String getSelectedRoleFilter() {
        return (String) roleFilterComboBox.getSelectedItem();
    }
}