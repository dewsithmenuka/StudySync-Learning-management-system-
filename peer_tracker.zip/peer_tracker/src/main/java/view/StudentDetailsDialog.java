package view;

import model.Course;
import model.User;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class StudentDetailsDialog extends JDialog {
    public StudentDetailsDialog(JFrame parent, User student, List<Course> courses) {
        super(parent, "Student Details: " + student.getName(), true);
        setSize(500, 400);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel detailsPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        detailsPanel.add(new JLabel("Name:"));
        detailsPanel.add(new JLabel(student.getName()));

        detailsPanel.add(new JLabel("Email:"));
        detailsPanel.add(new JLabel(student.getEmail()));

        detailsPanel.add(new JLabel("Role:"));
        detailsPanel.add(new JLabel(student.getRole()));

        detailsPanel.add(new JLabel("Phone:"));
        detailsPanel.add(new JLabel(student.getPhone() != null ? student.getPhone() : "N/A"));

        // Display courses
        JTextArea coursesArea = new JTextArea();
        coursesArea.setEditable(false);
        coursesArea.setLineWrap(true);
        coursesArea.setWrapStyleWord(true);
        if (courses != null && !courses.isEmpty()) {
            coursesArea.append("Enrolled Courses:\n");
            for (Course course : courses) {
                coursesArea.append("- " + course.getTitle() + "\n");
            }
        } else {
            coursesArea.append("No courses enrolled.");
        }
        JScrollPane coursesScrollPane = new JScrollPane(coursesArea);
        coursesScrollPane.setBorder(BorderFactory.createTitledBorder("Courses"));

        add(detailsPanel, BorderLayout.NORTH);
        add(coursesScrollPane, BorderLayout.CENTER);

        JButton closeButton = new JButton("Close");
        closeButton.addActionListener(e -> dispose());
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(closeButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }
}
