package dao;

import model.PeerReview;
import util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class PeerReviewDAO {
    // Create a peer review
    public boolean createPeerReview(PeerReview peerReview) {
        String sql = "INSERT INTO peer_reviews (submission_id, reviewer_id, rating, comments) " +
                     "VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, peerReview.getSubmissionId());
            pstmt.setInt(2, peerReview.getReviewerId());
            pstmt.setInt(3, peerReview.getRating());
            pstmt.setString(4, peerReview.getComments());
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error creating peer review: " + e.getMessage());
            return false;
        }
    }

    // Get reviews by submission
    public List<PeerReview> getReviewsBySubmission(int submissionId) {
        List<PeerReview> reviews = new ArrayList<>();
        String sql = "SELECT * FROM peer_reviews WHERE submission_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, submissionId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                reviews.add(extractPeerReviewFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting reviews by submission: " + e.getMessage());
        }
        return reviews;
    }

    // Get reviews by reviewer
    public List<PeerReview> getReviewsByReviewer(int reviewerId) {
        List<PeerReview> reviews = new ArrayList<>();
        String sql = "SELECT * FROM peer_reviews WHERE reviewer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, reviewerId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                reviews.add(extractPeerReviewFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting reviews by reviewer: " + e.getMessage());
        }
        return reviews;
    }

    // Get average rating for submission
    public double getAverageRating(int submissionId) {
        String sql = "SELECT AVG(rating) FROM peer_reviews WHERE submission_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, submissionId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return rs.getDouble(1);
            }
        } catch (SQLException e) {
            System.err.println("Error getting average rating: " + e.getMessage());
        }
        return 0.0;
    }

    // Helper method to extract PeerReview from ResultSet
    private PeerReview extractPeerReviewFromResultSet(ResultSet rs) throws SQLException {
        PeerReview review = new PeerReview();
        review.setReviewId(rs.getInt("review_id"));
        review.setSubmissionId(rs.getInt("submission_id"));
        review.setReviewerId(rs.getInt("reviewer_id"));
        review.setRating(rs.getInt("rating"));
        review.setComments(rs.getString("comments"));
        review.setReviewedAt(rs.getTimestamp("reviewed_at").toLocalDateTime());
        return review;
    }
}