package dao;

import model.Enrollment;
import model.StudentProgress; // Import StudentProgress model
import util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAO {
    // Enroll student in course
    public boolean enrollStudent(int studentId, int courseId) {
        String sql = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            pstmt.setInt(2, courseId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error enrolling student: " + e.getMessage());
            return false;
        }
    }

    // Get enrollments by student
    public List<Enrollment> getEnrollmentsByStudent(int studentId) {
        List<Enrollment> enrollments = new ArrayList<>();
        String sql = "SELECT * FROM enrollments WHERE student_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                enrollments.add(extractEnrollmentFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting enrollments by student: " + e.getMessage());
        }
        return enrollments;
    }

    // Get enrollments by course
    public List<Enrollment> getEnrollmentsByCourse(int courseId) {
        List<Enrollment> enrollments = new ArrayList<>();
        String sql = "SELECT * FROM enrollments WHERE course_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, courseId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                enrollments.add(extractEnrollmentFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting enrollments by course: " + e.getMessage());
        }
        return enrollments;
    }

    // Update enrollment progress
    public boolean updateProgress(int enrollmentId, int progress) {
        String sql = "UPDATE enrollments SET progress = ? WHERE enrollment_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, progress);
            pstmt.setInt(2, enrollmentId);

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating enrollment progress: " + e.getMessage());
            return false;
        }
    }

    // Remove enrollment
    public boolean removeEnrollment(int enrollmentId) {
        String sql = "DELETE FROM enrollments WHERE enrollment_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, enrollmentId);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error removing enrollment: " + e.getMessage());
            return false;
        }
    }

    // Helper method to extract Enrollment from ResultSet
    private Enrollment extractEnrollmentFromResultSet(ResultSet rs) throws SQLException {
        Enrollment enrollment = new Enrollment();
        enrollment.setEnrollmentId(rs.getInt("enrollment_id"));
        enrollment.setStudentId(rs.getInt("student_id"));
        enrollment.setCourseId(rs.getInt("course_id"));
        enrollment.setEnrolledAt(rs.getTimestamp("enrolled_at").toLocalDateTime());
        enrollment.setProgress(rs.getInt("progress"));
        return enrollment;
    }

    // New method to get student progress by teacher
    public List<StudentProgress> getStudentProgressByTeacher(int teacherId, String courseFilter) {
        List<StudentProgress> progressList = new ArrayList<>();
        StringBuilder sql = new StringBuilder("SELECT u.user_id, u.name AS student_name, c.course_id, c.title AS course_name, " +
                                              "e.progress, " +
                                              "COUNT(DISTINCT CASE WHEN s.grade IS NOT NULL THEN a.assignment_id END) AS completed_assignments, " +
                                              "COUNT(DISTINCT a.assignment_id) AS total_assignments, " +
                                              "AVG(s.grade) AS average_score, " +
                                              "MAX(s.submitted_at) AS last_active_date " +
                                              "FROM enrollments e " +
                                              "JOIN users u ON e.student_id = u.user_id " +
                                              "JOIN courses c ON e.course_id = c.course_id " +
                                              "LEFT JOIN assignments a ON c.course_id = a.course_id " +
                                              "LEFT JOIN submissions s ON a.assignment_id = s.assignment_id AND u.user_id = s.student_id " +
                                              "WHERE c.created_by = ? ");

        if (courseFilter != null && !courseFilter.isEmpty()) {
            sql.append("AND c.title = ? ");
        }

        sql.append("GROUP BY u.user_id, u.name, c.course_id, c.title, e.progress " +
                   "ORDER BY u.name, c.title");

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {

            pstmt.setInt(1, teacherId);
            if (courseFilter != null && !courseFilter.isEmpty()) {
                pstmt.setString(2, courseFilter);
            }

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int studentId = rs.getInt("user_id");
                String studentName = rs.getString("student_name");
                int courseId = rs.getInt("course_id");
                String courseName = rs.getString("course_name");
                int completedAssignments = rs.getInt("completed_assignments");
                int totalAssignments = rs.getInt("total_assignments");
                double averageScore = rs.getDouble("average_score");
                String lastActiveDate = rs.getTimestamp("last_active_date") != null ?
                                        rs.getTimestamp("last_active_date").toLocalDateTime().toLocalDate().toString() : "N/A";
                int progressPercentage = rs.getInt("progress"); // Assuming 'progress' column in enrollments stores percentage

                progressList.add(new StudentProgress(studentId, studentName, courseId, courseName,
                                                      completedAssignments, totalAssignments, averageScore,
                                                      lastActiveDate, progressPercentage));
            }
        } catch (SQLException e) {
            System.err.println("Error getting student progress by teacher: " + e.getMessage());
        }
        return progressList;
    }
    
    public List<StudentProgress> getStudentProgressByStudent(int studentId) {
        List<StudentProgress> progressList = new ArrayList<>();
        String sql = "SELECT u.user_id, u.name AS student_name, c.course_id, c.title AS course_name, " +
                     "e.progress, " +
                     "COUNT(DISTINCT CASE WHEN s.grade IS NOT NULL THEN a.assignment_id END) AS completed_assignments, " +
                     "COUNT(DISTINCT a.assignment_id) AS total_assignments, " +
                     "AVG(s.grade) AS average_score, " +
                     "MAX(s.submitted_at) AS last_active_date " +
                     "FROM enrollments e " +
                     "JOIN users u ON e.student_id = u.user_id " +
                     "JOIN courses c ON e.course_id = c.course_id " +
                     "LEFT JOIN assignments a ON c.course_id = a.course_id " +
                     "LEFT JOIN submissions s ON a.assignment_id = s.assignment_id AND u.user_id = s.student_id " +
                     "WHERE u.user_id = ? " + // Filter by specific student ID
                     "GROUP BY u.user_id, u.name, c.course_id, c.title, e.progress " +
                     "ORDER BY c.title";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int sId = rs.getInt("user_id");
                String studentName = rs.getString("student_name");
                int courseId = rs.getInt("course_id");
                String courseName = rs.getString("course_name");
                int completedAssignments = rs.getInt("completed_assignments");
                int totalAssignments = rs.getInt("total_assignments");
                double averageScore = rs.getDouble("average_score");
                String lastActiveDate = rs.getTimestamp("last_active_date") != null ?
                                        rs.getTimestamp("last_active_date").toLocalDateTime().toLocalDate().toString() : "N/A";
                int progressPercentage = rs.getInt("progress");

                progressList.add(new StudentProgress(sId, studentName, courseId, courseName,
                                                      completedAssignments, totalAssignments, averageScore,
                                                      lastActiveDate, progressPercentage));
            }
        } catch (SQLException e) {
            System.err.println("Error getting student progress by student: " + e.getMessage());
        }
        return progressList;
    }
}


