package dao;

import model.Resource;
import util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class ResourceDAO {
    public boolean createResource(Resource resource) {
        String sql = "INSERT INTO resources (mentor_id, title, description, file_path, upload_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, resource.getMentorId());
            pstmt.setString(2, resource.getTitle());
            pstmt.setString(3, resource.getDescription());
            pstmt.setString(4, resource.getFilePath());
            pstmt.setTimestamp(5, Timestamp.valueOf(resource.getUploadDate()));
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        resource.setResourceId(rs.getInt(1));
                        return true;
                    }
                }
            }
            return false;
        } catch (SQLException e) {
            System.err.println("Error creating resource: " + e.getMessage());
            return false;
        }
    }

    public Resource getResourceById(int resourceId) {
        String sql = "SELECT * FROM resources WHERE resource_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, resourceId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return extractResourceFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error getting resource by ID: " + e.getMessage());
        }
        return null;
    }

    public List<Resource> getResourcesByMentor(int mentorId) {
        List<Resource> resources = new ArrayList<>();
        String sql = "SELECT * FROM resources WHERE mentor_id = ? ORDER BY upload_date DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, mentorId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                resources.add(extractResourceFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting resources by mentor: " + e.getMessage());
        }
        return resources;
    }

    public boolean updateResource(Resource resource) {
        String sql = "UPDATE resources SET title = ?, description = ?, file_path = ? WHERE resource_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, resource.getTitle());
            pstmt.setString(2, resource.getDescription());
            pstmt.setString(3, resource.getFilePath());
            pstmt.setInt(4, resource.getResourceId());
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating resource: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteResource(int resourceId) {
        String sql = "DELETE FROM resources WHERE resource_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, resourceId);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting resource: " + e.getMessage());
            return false;
        }
    }

    private Resource extractResourceFromResultSet(ResultSet rs) throws SQLException {
        Resource resource = new Resource();
        resource.setResourceId(rs.getInt("resource_id"));
        resource.setMentorId(rs.getInt("mentor_id"));
        resource.setTitle(rs.getString("title"));
        resource.setDescription(rs.getString("description"));
        resource.setFilePath(rs.getString("file_path"));
        resource.setUploadDate(rs.getTimestamp("upload_date").toLocalDateTime());
        return resource;
    }
}
