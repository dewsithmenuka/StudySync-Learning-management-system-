package dao;

import model.MatchCriteria;
import model.User;
import util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MatchingDAO {
    public List<User> findMatchingPeers(MatchCriteria criteria) {
        List<User> matches = new ArrayList<>();
        String sql = "SELECT u.* FROM users u " +
                     "JOIN user_learning_preferences p ON u.user_id = p.user_id " +
                     "WHERE u.role = 'Student' AND u.user_id != ? " +
                     "AND p.skill_level = ? AND p.learning_style = ? " +
                     "AND u.is_active = TRUE";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, criteria.getUserId());
            pstmt.setString(2, criteria.getSkillLevel());
            pstmt.setString(3, criteria.getLearningStyle());
            
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                User user = new User();
                user.setUserId(rs.getInt("user_id"));
                user.setName(rs.getString("name"));
                user.setEmail(rs.getString("email"));
                // Set other fields as needed
                matches.add(user);
            }
        } catch (SQLException e) {
            System.err.println("Error finding matching peers: " + e.getMessage());
        }
        
        // Further filter by schedule compatibility and course interests
        matches.removeIf(user -> !isScheduleCompatible(user.getUserId(), criteria));
        matches.removeIf(user -> !hasCommonCourseInterests(user.getUserId(), criteria.getCourseInterests()));
        
        return matches;
    }
    
    private boolean isScheduleCompatible(int userId, MatchCriteria criteria) {
        // Implement schedule compatibility check
        // This could query the user_learning_preferences.availability JSON field
        return true; // Simplified for example
    }
    
    private boolean hasCommonCourseInterests(int userId, List<Integer> courseInterests) {
        if (courseInterests == null || courseInterests.isEmpty()) return true;
        
        // Query database for user's course interests and compare
        return true; // Simplified for example
    }
}