package dao;

import model.StudyGroup;
import util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class StudyGroupDAO {
    public boolean createStudyGroup(String name, String description, int creatorId,
                                  List<Integer> memberIds, String meetingSchedule,
                                  Integer courseId) {
        String sql = "INSERT INTO study_groups (name, description, creator_id, course_id, meeting_schedule) " +
                     "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, name);
            pstmt.setString(2, description);
            pstmt.setInt(3, creatorId);
            if (courseId != null) {
                pstmt.setInt(4, courseId);
            } else {
                pstmt.setNull(4, Types.INTEGER);
            }
            pstmt.setString(5, meetingSchedule);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        int groupId = rs.getInt(1);
                        // Now add members
                        for (int memberId : memberIds) {
                            addMemberToGroup(groupId, memberId);
                        }
                        return true;
                    }
                }
            }
        } catch (SQLException e) {
            System.err.println("Error creating study group: " + e.getMessage());
        }
        return false;
    }

    public boolean addMemberToGroup(int groupId, int userId) {
        String sql = "INSERT INTO group_members (group_id, user_id) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, groupId);
            pstmt.setInt(2, userId);

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error adding member to group: " + e.getMessage());
            return false;
        }
    }

    public boolean updateStudyGroup(StudyGroup group) {
        String sql = "UPDATE study_groups SET name = ?, description = ?, meeting_schedule = ?, course_id = ? WHERE group_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, group.getName());
            pstmt.setString(2, group.getDescription());
            pstmt.setString(3, group.getMeetingSchedule());
            if (group.getCourseId() != null) {
                pstmt.setInt(4, group.getCourseId());
            } else {
                pstmt.setNull(4, Types.INTEGER);
            }
            pstmt.setInt(5, group.getGroupId());

            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating study group: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteStudyGroup(int groupId) {
        // First, delete members from group_members table
        String deleteMembersSql = "DELETE FROM group_members WHERE group_id = ?";
        // Then, delete the group itself
        String deleteGroupSql = "DELETE FROM study_groups WHERE group_id = ?";

        try (Connection conn = DatabaseConnection.getConnection()) {
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement pstmtMembers = conn.prepareStatement(deleteMembersSql);
                 PreparedStatement pstmtGroup = conn.prepareStatement(deleteGroupSql)) {

                pstmtMembers.setInt(1, groupId);
                pstmtMembers.executeUpdate(); // Delete members

                pstmtGroup.setInt(1, groupId);
                int affectedRows = pstmtGroup.executeUpdate(); // Delete group

                conn.commit(); // Commit transaction
                return affectedRows > 0;

            } catch (SQLException e) {
                conn.rollback(); // Rollback on error
                System.err.println("Error deleting study group: " + e.getMessage());
                return false;
            } finally {
                conn.setAutoCommit(true); // Restore auto-commit
            }
        } catch (SQLException e) {
            System.err.println("Error managing transaction for study group deletion: " + e.getMessage());
            return false;
        }
    }

    public StudyGroup getStudyGroupById(int groupId) {
        String sql = "SELECT * FROM study_groups WHERE group_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, groupId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                StudyGroup group = extractStudyGroupFromResultSet(rs);
                group.setMemberIds(getMembersOfGroup(groupId)); // Load members
                return group;
            }
        } catch (SQLException e) {
            System.err.println("Error getting study group by ID: " + e.getMessage());
        }
        return null;
    }

    public List<StudyGroup> getGroupsForUser (int userId) {
        List<StudyGroup> groups = new ArrayList<>();
        String sql = "SELECT sg.* FROM study_groups sg " +
                     "JOIN group_members gm ON sg.group_id = gm.group_id " +
                     "WHERE gm.user_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                StudyGroup group = extractStudyGroupFromResultSet(rs);
                group.setMemberIds(getMembersOfGroup(group.getGroupId())); // Load members for each group
                groups.add(group);
            }
        } catch (SQLException e) {
            System.err.println("Error getting groups for user: " + e.getMessage());
        }
        return groups;
    }

    private List<Integer> getMembersOfGroup(int groupId) {
        List<Integer> memberIds = new ArrayList<>();
        String sql = "SELECT user_id FROM group_members WHERE group_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, groupId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                memberIds.add(rs.getInt("user_id"));
            }
        } catch (SQLException e) {
            System.err.println("Error getting members of group: " + e.getMessage());
        }
        return memberIds;
    }

    // New method to get all study groups
    public List<StudyGroup> getAllStudyGroups() {
        List<StudyGroup> groups = new ArrayList<>();
        String sql = "SELECT * FROM study_groups";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                StudyGroup group = extractStudyGroupFromResultSet(rs);
                group.setMemberIds(getMembersOfGroup(group.getGroupId())); // Load members for each group
                groups.add(group);
            }
        } catch (SQLException e) {
            System.err.println("Error getting all study groups: " + e.getMessage());
        }
        return groups;
    }

    private StudyGroup extractStudyGroupFromResultSet(ResultSet rs) throws SQLException {
        StudyGroup group = new StudyGroup();
        group.setGroupId(rs.getInt("group_id"));
        group.setName(rs.getString("name"));
        group.setDescription(rs.getString("description"));
        group.setCreatorId(rs.getInt("creator_id"));
        group.setCourseId(rs.getObject("course_id", Integer.class)); // Handle nullable Integer
        group.setMeetingSchedule(rs.getString("meeting_schedule"));
        group.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        return group;
    }
}
