package dao;

import model.Question;
import model.Quiz;
import util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class QuizDAO {
    public boolean createQuiz(Quiz quiz) {
        String sql = "INSERT INTO quizzes (course_id, title, description, available_from, " +
                     "available_to, time_limit, is_published) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, quiz.getCourseId());
            pstmt.setString(2, quiz.getTitle());
            pstmt.setString(3, quiz.getDescription());
            pstmt.setTimestamp(4, Timestamp.valueOf(quiz.getAvailableFrom()));
            pstmt.setTimestamp(5, Timestamp.valueOf(quiz.getAvailableTo()));
            pstmt.setInt(6, quiz.getTimeLimit());
            pstmt.setBoolean(7, quiz.isPublished());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        quiz.setQuizId(rs.getInt(1));
                        return saveQuestions(quiz.getQuestions(), quiz.getQuizId());
                    }
                }
            }
            return false;
        } catch (SQLException e) {
            System.err.println("Error creating quiz: " + e.getMessage());
            return false;
        }
    }
    
    private boolean saveQuestions(List<Question> questions, int quizId) throws SQLException {
        String sql = "INSERT INTO questions (quiz_id, question_text, type, options, " +
                     "correct_answer, points, explanation) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            for (Question question : questions) {
                pstmt.setInt(1, quizId);
                pstmt.setString(2, question.getQuestionText());
                pstmt.setString(3, question.getType().name());
                pstmt.setString(4, String.join(";;", question.getOptions()));
                pstmt.setString(5, question.getCorrectAnswer());
                pstmt.setInt(6, question.getPoints());
                pstmt.setString(7, question.getExplanation());
                pstmt.addBatch();
            }
            
            int[] results = pstmt.executeBatch();
            for (int result : results) {
                if (result <= 0) return false;
            }
            return true;
        }
    }
    
    public List<Quiz> getQuizzesByCourse(int courseId) {
        List<Quiz> quizzes = new ArrayList<>();
        String sql = "SELECT * FROM quizzes WHERE course_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, courseId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Quiz quiz = new Quiz();
                quiz.setQuizId(rs.getInt("quiz_id"));
                quiz.setCourseId(rs.getInt("course_id"));
                quiz.setTitle(rs.getString("title"));
                quiz.setDescription(rs.getString("description"));
                quiz.setAvailableFrom(rs.getTimestamp("available_from").toLocalDateTime());
                quiz.setAvailableTo(rs.getTimestamp("available_to").toLocalDateTime());
                quiz.setTimeLimit(rs.getInt("time_limit"));
                quiz.setPublished(rs.getBoolean("is_published"));
                quiz.setQuestions(getQuestionsForQuiz(quiz.getQuizId()));
                quizzes.add(quiz);
            }
        } catch (SQLException e) {
            System.err.println("Error getting quizzes by course: " + e.getMessage());
        }
        return quizzes;
    }
    
    private List<Question> getQuestionsForQuiz(int quizId) throws SQLException {
        List<Question> questions = new ArrayList<>();
        String sql = "SELECT * FROM questions WHERE quiz_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, quizId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                Question question = new Question();
                question.setQuestionId(rs.getInt("question_id"));
                question.setQuizId(rs.getInt("quiz_id"));
                question.setQuestionText(rs.getString("question_text"));
                question.setType(Question.QuestionType.valueOf(rs.getString("type")));
                
                String optionsStr = rs.getString("options");
                question.setOptions(List.of(optionsStr.split(";;")));
                
                question.setCorrectAnswer(rs.getString("correct_answer"));
                question.setPoints(rs.getInt("points"));
                question.setExplanation(rs.getString("explanation"));
                questions.add(question);
            }
        }
        return questions;
    }
    
    // Additional methods for quiz management
    public boolean publishQuiz(int quizId) {
        String sql = "UPDATE quizzes SET is_published = TRUE WHERE quiz_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, quizId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error publishing quiz: " + e.getMessage());
            return false;
        }
    }
}