package dao;

import model.Session;
import util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SessionDAO {
    public boolean createSession(Session session) {
        String sql = "INSERT INTO sessions (mentor_id, mentee_id, title, description, start_time, end_time, location) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, session.getMentorId());
            pstmt.setInt(2, session.getMenteeId());
            pstmt.setString(3, session.getTitle());
            pstmt.setString(4, session.getDescription());
            pstmt.setTimestamp(5, Timestamp.valueOf(session.getStartTime()));
            pstmt.setTimestamp(6, Timestamp.valueOf(session.getEndTime()));
            pstmt.setString(7, session.getLocation());
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        session.setSessionId(rs.getInt(1));
                        return true;
                    }
                }
            }
            return false;
        } catch (SQLException e) {
            System.err.println("Error creating session: " + e.getMessage());
            return false;
        }
    }

    public Session getSessionById(int sessionId) {
        String sql = "SELECT * FROM sessions WHERE session_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, sessionId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return extractSessionFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error getting session by ID: " + e.getMessage());
        }
        return null;
    }

    public List<Session> getSessionsByMentor(int mentorId) {
        List<Session> sessions = new ArrayList<>();
        String sql = "SELECT * FROM sessions WHERE mentor_id = ? ORDER BY start_time ASC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, mentorId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                sessions.add(extractSessionFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting sessions by mentor: " + e.getMessage());
        }
        return sessions;
    }

    public List<Session> getSessionsByMentee(int menteeId) {
        List<Session> sessions = new ArrayList<>();
        String sql = "SELECT * FROM sessions WHERE mentee_id = ? ORDER BY start_time ASC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, menteeId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                sessions.add(extractSessionFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting sessions by mentee: " + e.getMessage());
        }
        return sessions;
    }

    public boolean updateSession(Session session) {
        String sql = "UPDATE sessions SET mentee_id = ?, title = ?, description = ?, start_time = ?, end_time = ?, location = ? WHERE session_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, session.getMenteeId());
            pstmt.setString(2, session.getTitle());
            pstmt.setString(3, session.getDescription());
            pstmt.setTimestamp(4, Timestamp.valueOf(session.getStartTime()));
            pstmt.setTimestamp(5, Timestamp.valueOf(session.getEndTime()));
            pstmt.setString(6, session.getLocation());
            pstmt.setInt(7, session.getSessionId());
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating session: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteSession(int sessionId) {
        String sql = "DELETE FROM sessions WHERE session_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, sessionId);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting session: " + e.getMessage());
            return false;
        }
    }

    private Session extractSessionFromResultSet(ResultSet rs) throws SQLException {
        Session session = new Session();
        session.setSessionId(rs.getInt("session_id"));
        session.setMentorId(rs.getInt("mentor_id"));
        session.setMenteeId(rs.getInt("mentee_id"));
        session.setTitle(rs.getString("title"));
        session.setDescription(rs.getString("description"));
        session.setStartTime(rs.getTimestamp("start_time").toLocalDateTime());
        session.setEndTime(rs.getTimestamp("end_time").toLocalDateTime());
        session.setLocation(rs.getString("location"));
        return session;
    }
}
