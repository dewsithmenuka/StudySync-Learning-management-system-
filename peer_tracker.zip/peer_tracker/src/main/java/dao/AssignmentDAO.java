package dao;

import model.Assignment;
import util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class AssignmentDAO {
    // Create a new assignment
    public boolean createAssignment(Assignment assignment) {
        String sql = "INSERT INTO assignments (course_id, title, description, due_date, created_by) " +
                     "VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            pstmt.setInt(1, assignment.getCourseId());
            pstmt.setString(2, assignment.getTitle());
            pstmt.setString(3, assignment.getDescription());
            pstmt.setTimestamp(4, Timestamp.valueOf(assignment.getDueDate()));
            pstmt.setInt(5, assignment.getCreatedBy());
            
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet rs = pstmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        assignment.setAssignmentId(rs.getInt(1));
                        return true;
                    }
                }
            }
            return false;
        } catch (SQLException e) {
            System.err.println("Error creating assignment: " + e.getMessage());
            return false;
        }
    }

    // Get assignments by course
    public List<Assignment> getAssignmentsByCourse(int courseId) {
        List<Assignment> assignments = new ArrayList<>();
        String sql = "SELECT * FROM assignments WHERE course_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, courseId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                assignments.add(extractAssignmentFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting assignments by course: " + e.getMessage());
        }
        return assignments;
    }

    // Get assignments by teacher
    public List<Assignment> getAssignmentsByTeacher(int teacherId) {
        List<Assignment> assignments = new ArrayList<>();
        String sql = "SELECT * FROM assignments WHERE created_by = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, teacherId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                assignments.add(extractAssignmentFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting assignments by teacher: " + e.getMessage());
        }
        return assignments;
    }

    // Get assignment by ID
    public Assignment getAssignmentById(int assignmentId) {
        String sql = "SELECT * FROM assignments WHERE assignment_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, assignmentId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractAssignmentFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error getting assignment by ID: " + e.getMessage());
        }
        return null;
    }

    // Update assignment
    public boolean updateAssignment(Assignment assignment) {
        String sql = "UPDATE assignments SET title = ?, description = ?, due_date = ? " +
                     "WHERE assignment_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setString(1, assignment.getTitle());
            pstmt.setString(2, assignment.getDescription());
            pstmt.setTimestamp(3, Timestamp.valueOf(assignment.getDueDate()));
            pstmt.setInt(4, assignment.getAssignmentId());
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error updating assignment: " + e.getMessage());
            return false;
        }
    }

    // Delete assignment
    public boolean deleteAssignment(int assignmentId) {
        String sql = "DELETE FROM assignments WHERE assignment_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, assignmentId);
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting assignment: " + e.getMessage());
            return false;
        }
    }

    // Helper method to extract Assignment from ResultSet
    private Assignment extractAssignmentFromResultSet(ResultSet rs) throws SQLException {
        Assignment assignment = new Assignment();
        assignment.setAssignmentId(rs.getInt("assignment_id"));
        assignment.setCourseId(rs.getInt("course_id"));
        assignment.setTitle(rs.getString("title"));
        assignment.setDescription(rs.getString("description"));
        assignment.setDueDate(rs.getTimestamp("due_date").toLocalDateTime());
        assignment.setCreatedBy(rs.getInt("created_by"));
        assignment.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
        return assignment;
    }
}