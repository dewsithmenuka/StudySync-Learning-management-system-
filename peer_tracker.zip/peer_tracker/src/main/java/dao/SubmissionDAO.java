package dao;

import model.Submission;
import util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class SubmissionDAO {
    // Submit an assignment
    public boolean submitAssignment(Submission submission) {
        String sql = "INSERT INTO submissions (assignment_id, student_id, file_path) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, submission.getAssignmentId());
            pstmt.setInt(2, submission.getStudentId());
            pstmt.setString(3, submission.getFilePath());
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error submitting assignment: " + e.getMessage());
            return false;
        }
    }

    // Get submissions by assignment
    public List<Submission> getSubmissionsByAssignment(int assignmentId) {
        List<Submission> submissions = new ArrayList<>();
        String sql = "SELECT * FROM submissions WHERE assignment_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, assignmentId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                submissions.add(extractSubmissionFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting submissions by assignment: " + e.getMessage());
        }
        return submissions;
    }

    // Get submissions by student
    public List<Submission> getSubmissionsByStudent(int studentId) {
        List<Submission> submissions = new ArrayList<>();
        String sql = "SELECT * FROM submissions WHERE student_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, studentId);
            ResultSet rs = pstmt.executeQuery();
            
            while (rs.next()) {
                submissions.add(extractSubmissionFromResultSet(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error getting submissions by student: " + e.getMessage());
        }
        return submissions;
    }

    // Grade submission
    public boolean gradeSubmission(int submissionId, int grade, String feedback) {
        String sql = "UPDATE submissions SET grade = ?, feedback = ? WHERE submission_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, grade);
            pstmt.setString(2, feedback);
            pstmt.setInt(3, submissionId);
            
            int affectedRows = pstmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            System.err.println("Error grading submission: " + e.getMessage());
            return false;
        }
    }

    // Get submission by ID
    public Submission getSubmissionById(int submissionId) {
        String sql = "SELECT * FROM submissions WHERE submission_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            pstmt.setInt(1, submissionId);
            ResultSet rs = pstmt.executeQuery();
            
            if (rs.next()) {
                return extractSubmissionFromResultSet(rs);
            }
        } catch (SQLException e) {
            System.err.println("Error getting submission by ID: " + e.getMessage());
        }
        return null;
    }

    // Helper method to extract Submission from ResultSet
    private Submission extractSubmissionFromResultSet(ResultSet rs) throws SQLException {
        Submission submission = new Submission();
        submission.setSubmissionId(rs.getInt("submission_id"));
        submission.setAssignmentId(rs.getInt("assignment_id"));
        submission.setStudentId(rs.getInt("student_id"));
        submission.setFilePath(rs.getString("file_path"));
        submission.setSubmittedAt(rs.getTimestamp("submitted_at").toLocalDateTime());
        submission.setGrade(rs.getInt("grade"));
        if (rs.wasNull()) {
            submission.setGrade(null);
        }
        submission.setFeedback(rs.getString("feedback"));
        return submission;
    }
}